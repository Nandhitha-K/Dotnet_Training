﻿namespace JaggedArrayDemo
{
    internal class Program {
        static void Main(string[] args) {
            string[][] familyMembers;       // Declare the jagged array
            Console.Write("How many families? ");
            int familyCount = Convert.ToInt32(Console.ReadLine());
            familyMembers = new string[familyCount][];  // Instantiate no. of rows
            for (int f = 0; f < familyCount; f++) {
                Console.Write($"How many members in family # {f+1}? ");
                int memberCount = Convert.ToInt16(Console.ReadLine());
                familyMembers[f] = new string[memberCount]; // Instantiate no. of cols in the row
                for (int m = 0; m < memberCount; m++) {
                    Console.Write("Enter the member name: ");
                    familyMembers[f][m] = Console.ReadLine();
                }
            }
            Console.WriteLine("Census details are...");
            for (int f = 0; f < familyCount; f++) {
                for (int m = 0; m < familyMembers[f].Length; m++) {
                    Console.Write(familyMembers[f][m]);
                    Console.Write("\t");
                }
                Console.WriteLine();
            }
        }
    }
}
