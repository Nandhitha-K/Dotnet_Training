Imports System
Module M1
  Sub Main()
    Console.WriteLine("Welcome to MS.NET")
    Console.WriteLine("This is a VB program")
  End Sub
End Module