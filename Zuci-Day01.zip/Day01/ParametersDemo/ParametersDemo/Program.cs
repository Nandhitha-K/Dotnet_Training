﻿namespace ParametersDemo
{
    internal class Program
    {
        static int Add(int x, int y)    // Parameters
        {
            int z;
            z = x + y;
            return z;
        }
        static void Increment(int x)    // Input parameter (IN param)
        {
            x++;
        }
        static void Decrement(out int x)    // Output parameter (OUT param)
        {
            x = 0;
            x--;
        }
        static void SumAndProduct(int x, int y, out int sum, out int product)
        {
            sum = x + y;
            product = x * y;
        }
        static void Swap(ref int x, ref int y)  // ref parameters (pass by reference)
        {
            int t = x;
            x = y;
            y = t;
        }
        static void PrintNames(params string[] names)   // parameter array
        {
            foreach (string name in names)
            {
                Console.WriteLine(name);
            }
        }
        static void Main(string[] args)
        {
            PrintNames("Ramesh");
            PrintNames("Ramesh", "Usha");
            PrintNames("Suresh", "Devi", "Hari");
            int a, b, c;
            a = 4;  b = 5;
            //c = Add(a, b);      // Arguments
            c = Add(y: b, x: a);    // Named arguments
            Console.WriteLine($"Addition = {c}");
            Increment(a);
            Console.WriteLine($"a = {a}");
            Decrement(out a);
            Console.WriteLine($"a = {a}");
            int res1, res2;
            SumAndProduct(a, b, out res1, out res2);
            Console.WriteLine($"Sum={res1}, Product={res2}");
            Swap(ref a, ref b);
            Console.WriteLine($"a={a}, b={b}");
        }
    }
}
