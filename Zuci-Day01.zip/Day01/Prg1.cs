using System;
class Program
{
  public static void Main()
  {
    Console.WriteLine("Welome to MS.NET");
    Console.WriteLine("This is a C# program");
  }
}
