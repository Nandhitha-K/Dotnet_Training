﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
             // int num;
            System.Int32 num;
            num = 5;
            //num = "Apple";
            object x;
            x = 10;
            x = "Grape";
            string name;
            Console.Write("Enter your name: ");
            name = Console.ReadLine();
            int empId;
            Console.Write("Enter emp id: ");
            empId = Convert.ToInt32(Console.ReadLine());
            DateTime doBirth;
            Console.Write("Enter date of birth: ");
            doBirth = Convert.ToDateTime(Console.ReadLine());
            //Console.WriteLine("Emp Id: {0}, Name: {1}, DoB: {2}", empId, name, doBirth);
            // OR
            Console.WriteLine($"Emp Id: {empId}, Name: {name}, DoB: {doBirth}");
        }
    }
}
