﻿namespace StructureDemo
{
    struct Employee
    {
        public int empId;
        public string empName;
        public decimal salary;
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp;
            Console.Write("Enter emp id: ");
            emp.empId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter name: ");
            emp.empName = Console.ReadLine();
            Console.Write("Enter salary: ");
            emp.salary = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine($"Emp Id: {emp.empId}, Name: {emp.empName}, Sal: {emp.salary}");
        }
    }
}
