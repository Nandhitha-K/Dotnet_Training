﻿namespace OptionalParamDemo
{
    internal class Program
    {
        /*static void SendEmail(string fromAddr, string toAddr)
        {
            // some code to send email
        }
        static void SendEmail(string fromAddr, string toAddr, string ccAddr)
        {
            // some code to send email
        }
        static void SendEmail(string fromAddr, string toAddr, string ccAddr, string bccAddr)
        {
            // some code to send email
        }*/
        // Optional parameters
        static void SendEmail(string fromAddr, string toAddr, string ccAddr="", string bccAddr=null)
        {
            // some code to send email
        }
        static void Main(string[] args)
        {
            SendEmail("abc@zuci.com", "xyz@zuci.com");
            SendEmail("abc@zuci.com", "xyz@zuci.com", "bcd@zuci.com");
            SendEmail("abc@zuci.com", "xyz@zuci.com", "bcd@zuci.com", "cde@zuci.com");
            SendEmail("abc@zuci.com", "xyz@zuci.com", bccAddr:"cde@zuci.com");
        }
    }
}
