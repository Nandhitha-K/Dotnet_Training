﻿namespace EnumDemo
{
    enum WeekDays  { Sun, Mon, Tue, Wed, Thu, Fri, Sat }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working days are...");
            for (WeekDays wd = WeekDays.Mon; wd <= WeekDays.Fri; wd++)
            {
                Console.WriteLine(wd);
            }
        }
    }
}
