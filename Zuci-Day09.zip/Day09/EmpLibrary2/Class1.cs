﻿namespace EmpLibrary2;

public class Class1
{

}
