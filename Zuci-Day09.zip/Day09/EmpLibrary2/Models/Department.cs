﻿using System;
using System.Collections.Generic;

namespace EmpLibrary2.Models;

public partial class Department
{
    public int DeptId { get; set; }

    public string? DeptName { get; set; }
}
