﻿using System;
using System.Collections.Generic;

namespace EmpLibrary2.Models;

public partial class VEmp4
{
    public int EId { get; set; }

    public string? EName { get; set; }

    public decimal? Sal { get; set; }

    public decimal? HRA { get; set; }
}
