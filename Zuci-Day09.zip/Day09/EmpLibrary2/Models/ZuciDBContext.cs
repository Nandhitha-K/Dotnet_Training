﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EmpLibrary2.Models;

public partial class ZuciDBContext : DbContext
{
    public ZuciDBContext()
    {
    }

    public ZuciDBContext(DbContextOptions<ZuciDBContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<Empl> Empls { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<VEmp1> VEmp1s { get; set; }

    public virtual DbSet<VEmp2> VEmp2s { get; set; }

    public virtual DbSet<VEmp3> VEmp3s { get; set; }

    public virtual DbSet<VEmp4> VEmp4s { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("server=(localdb)\\MSSQLLocalDB; database=ZuciDB; integrated security=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.DeptId).HasName("PK__Departme__014881AE44162C96");

            entity.ToTable("Department");

            entity.Property(e => e.DeptId).ValueGeneratedNever();
            entity.Property(e => e.DeptName)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Empl>(entity =>
        {
            entity.HasKey(e => e.EmpId).HasName("PK__Empl__AF2DBB99C0E3327A");

            entity.ToTable("Empl");

            entity.Property(e => e.EmpId).ValueGeneratedNever();
            entity.Property(e => e.EmpName)
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.HasOne(d => d.Mgr).WithMany(p => p.InverseMgr)
                .HasForeignKey(d => d.MgrId)
                .HasConstraintName("FK__Empl__MgrId__5FB337D6");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.EmpId).HasName("PK__Employee__AF2DBB99AAE90B02");

            entity.ToTable("Employee", tb =>
                {
                    tb.HasTrigger("EMP_DEL");
                    tb.HasTrigger("EMP_INSERT");
                    tb.HasTrigger("EMP_INSERT2");
                    tb.HasTrigger("EMP_UPD");
                });

            entity.HasIndex(e => e.EmpName, "IDX_ENAME");

            entity.Property(e => e.EmpId).ValueGeneratedNever();
            entity.Property(e => e.EmpName)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.Salary).HasColumnType("money");
        });

        modelBuilder.Entity<VEmp1>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("VEmp1");

            entity.Property(e => e.EmpName)
                .HasMaxLength(40)
                .IsUnicode(false);
        });

        modelBuilder.Entity<VEmp2>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("VEmp2");

            entity.Property(e => e.EmpName)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.Salary).HasColumnType("money");
        });

        modelBuilder.Entity<VEmp3>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("VEmp3");

            entity.Property(e => e.EName)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.HRA).HasColumnType("numeric(22, 6)");
            entity.Property(e => e.Sal).HasColumnType("money");
        });

        modelBuilder.Entity<VEmp4>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("VEmp4");

            entity.Property(e => e.EName)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.HRA).HasColumnType("numeric(22, 6)");
            entity.Property(e => e.Sal).HasColumnType("money");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
