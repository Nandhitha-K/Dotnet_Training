﻿using System;
using System.Collections.Generic;

namespace EmpLibrary2.Models;

public partial class Empl
{
    public int EmpId { get; set; }

    public string EmpName { get; set; } = null!;

    public int? MgrId { get; set; }

    public virtual ICollection<Empl> InverseMgr { get; set; } = new List<Empl>();

    public virtual Empl? Mgr { get; set; }
}
