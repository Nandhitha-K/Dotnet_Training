﻿using System;
using System.Collections.Generic;

namespace EmpLibrary2.Models;

public partial class VEmp1
{
    public int EmpId { get; set; }

    public string? EmpName { get; set; }
}
