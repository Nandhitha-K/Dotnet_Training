﻿using System;
using System.Collections.Generic;

namespace EmpLibrary2.Models;

public partial class VEmp2
{
    public int EmpId { get; set; }

    public string? EmpName { get; set; }

    public decimal? Salary { get; set; }

    public DateOnly? DoBirth { get; set; }
}
