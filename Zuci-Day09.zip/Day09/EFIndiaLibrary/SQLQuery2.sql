﻿CREATE TABLE IndianCity (
CityCode CHAR(4) PRIMARY KEY,
CityName VARCHAR(20) NOT NULL,
StateCode NVARCHAR(2) REFERENCES IndianState(StateCode),
CityPopulation BIGINT)
