﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EFIndiaLibrary.Models;

public partial class IndiaDBContext : DbContext
{
    public IndiaDBContext()
    {
    }

    public IndiaDBContext(DbContextOptions<IndiaDBContext> options)
        : base(options)
    {
    }

    public virtual DbSet<IndianCity> IndianCities { get; set; }

    public virtual DbSet<IndianState> IndianStates { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("data source=(localdb)\\MSSQLLocalDB; database=IndiaDB; integrated security=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<IndianCity>(entity =>
        {
            entity.HasKey(e => e.CityCode).HasName("PK__IndianCi__B488218D9BE49382");

            entity.ToTable("IndianCity");

            entity.Property(e => e.CityCode)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CityName)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.StateCode).HasMaxLength(2);

            entity.HasOne(d => d.StateCodeNavigation).WithMany(p => p.IndianCities)
                .HasForeignKey(d => d.StateCode)
                .HasConstraintName("FK__IndianCit__State__4CA06362");
        });

        modelBuilder.Entity<IndianState>(entity =>
        {
            entity.HasKey(e => e.StateCode);

            entity.ToTable("IndianState");

            entity.Property(e => e.StateCode).HasMaxLength(2);
            entity.Property(e => e.StateLanguage).HasMaxLength(10);
            entity.Property(e => e.StateName).HasMaxLength(20);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
