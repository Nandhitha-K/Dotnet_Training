﻿using System;
using System.Collections.Generic;

namespace EFIndiaLibrary.Models;

public partial class IndianCity
{
    public string CityCode { get; set; } = null!;

    public string CityName { get; set; } = null!;

    public string? StateCode { get; set; }

    public long? CityPopulation { get; set; }

    public virtual IndianState? StateCodeNavigation { get; set; }
}
