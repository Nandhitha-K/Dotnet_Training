﻿using System;
using System.Collections.Generic;

namespace EFIndiaLibrary.Models;

public partial class IndianState
{
    public string StateCode { get; set; } = null!;

    public string StateName { get; set; } = null!;

    public double StateArea { get; set; }

    public string StateLanguage { get; set; } = null!;

    public virtual ICollection<IndianCity> IndianCities { get; set; } = new List<IndianCity>();
}
