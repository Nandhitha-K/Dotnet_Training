﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFIndiaLibrary2.Models
{
    [Table("IndianState")]
    public class IndianState
    {
        [Key]
        [StringLength(2)]
        public string StateCode { get; set; }
        [StringLength(20)]
        [Required]
        public string StateName { get; set; }
        public double StateArea { get; set; }
        [StringLength(10)]
        public string StateLanguage { get; set; }
    }
}
