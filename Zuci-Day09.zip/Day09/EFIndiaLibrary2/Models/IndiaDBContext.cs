﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFIndiaLibrary2.Models
{
    public class IndiaDBContext : DbContext
    {
        public IndiaDBContext()
        {

        }
        public IndiaDBContext(DbContextOptions<IndiaDBContext> options) : base(options)
        {

        }
        public virtual DbSet<IndianState> IndianStates { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"server=(localdb)\MSSQLLocalDB; database=IndiaDB; integrated security=true");
        }
    }

}
