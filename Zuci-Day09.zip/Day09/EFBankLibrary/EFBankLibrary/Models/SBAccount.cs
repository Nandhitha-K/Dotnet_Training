﻿using System;
using System.Collections.Generic;

namespace EFBankLibrary.Models;

public partial class SBAccount
{
    public string AccountNumber { get; set; } = null!;

    public string CustomerName { get; set; } = null!;

    public string? CustomerAddress { get; set; }

    public decimal? CurrentBalance { get; set; }

    public virtual ICollection<SBTransaction> SBTransactions { get; set; } = new List<SBTransaction>();
}
