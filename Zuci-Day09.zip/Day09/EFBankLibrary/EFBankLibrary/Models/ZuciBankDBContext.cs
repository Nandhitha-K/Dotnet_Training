﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EFBankLibrary.Models;

public partial class ZuciBankDBContext : DbContext
{
    public ZuciBankDBContext()
    {
    }

    public ZuciBankDBContext(DbContextOptions<ZuciBankDBContext> options)
        : base(options)
    {
    }

    public virtual DbSet<SBAccount> SBAccounts { get; set; }

    public virtual DbSet<SBTransaction> SBTransactions { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("data source=(localdb)\\MSSQLLocalDB; database=ZuciBankDB; integrated security=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SBAccount>(entity =>
        {
            entity.HasKey(e => e.AccountNumber).HasName("PK__SBAccoun__BE2ACD6E9F979981");

            entity.ToTable("SBAccount");

            entity.Property(e => e.AccountNumber)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CurrentBalance).HasColumnType("money");
            entity.Property(e => e.CustomerAddress)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CustomerName)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        modelBuilder.Entity<SBTransaction>(entity =>
        {
            entity.HasKey(e => e.TransactionId).HasName("PK__SBTransa__55433A6B461BAB72");

            entity.ToTable("SBTransaction");

            entity.Property(e => e.AccountNumber)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.Amount).HasColumnType("money");
            entity.Property(e => e.TransactionDate).HasColumnType("datetime");
            entity.Property(e => e.TransactionType)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();

            entity.HasOne(d => d.AccountNumberNavigation).WithMany(p => p.SBTransactions)
                .HasForeignKey(d => d.AccountNumber)
                .HasConstraintName("FK__SBTransac__Accou__38996AB5");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
