﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
MyClassLib1.Class1 obj = new MyClassLib1.Class1();
obj.Wish();
