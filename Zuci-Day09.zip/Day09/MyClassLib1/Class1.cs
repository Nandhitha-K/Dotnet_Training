﻿namespace MyClassLib1;

public class Class1
{
    public void Wish()
    {
        Console.WriteLine("Good morning");
    }
}
