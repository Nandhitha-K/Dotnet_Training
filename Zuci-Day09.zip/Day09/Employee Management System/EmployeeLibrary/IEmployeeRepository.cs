﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace EmployeeLibrary
{
    public interface IEmployeeRepository
    {
        Task<ArrayList> GetAllEmployees();
        Task<Employee> GetEmployeeById(int eid);
        Task InsertEmployee(Employee employee);
        Task UpdateEmployee(int eid, Employee employee);
        Task DeleteEmployee(int eid);
    }
}
