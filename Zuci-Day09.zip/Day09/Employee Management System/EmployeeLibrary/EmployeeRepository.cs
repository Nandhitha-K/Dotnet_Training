﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class EmployeeRepository : IEmployeeRepository {
        static ArrayList employees = new ArrayList();
        public async Task DeleteEmployee(int eid) {
            Employee emp2del = await GetEmployeeById(eid);
            employees.Remove(emp2del);
        }
        public async Task<ArrayList> GetAllEmployees() {
            return employees;
        }
        public async Task<Employee> GetEmployeeById(int eid) {
            Employee emp = null;
            foreach (Employee employee in employees) {
                if (employee.EmpId == eid) {
                    emp = employee;
                    break;
                }
            }
            return emp;
        }
        public async Task InsertEmployee(Employee employee) {
            employees.Add(employee);
        }
        public async Task UpdateEmployee(int eid, Employee employee) {
            Employee emp2edit = await GetEmployeeById(eid);
            emp2edit.EmpName = employee.EmpName;
            emp2edit.Salary = employee.Salary;
        }
    }
}
