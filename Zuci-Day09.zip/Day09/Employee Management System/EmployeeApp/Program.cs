﻿using EmployeeLibrary;
using System.Collections;
namespace EmployeeApp {
    internal class Program {
        static void Main(string[] args) {
            while (true) {
                Console.WriteLine("-------------------");
                Console.WriteLine("- - - M E N U - - -");
                Console.WriteLine("-------------------");
                Console.WriteLine("1. New Employee");
                Console.WriteLine("2. View Employee");
                Console.WriteLine("3. View All Emps");
                Console.WriteLine("4. Update Employee");
                Console.WriteLine("5. Delete Employee");
                Console.WriteLine("6. Quit");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch(choice) {
                    case 1: NewEmployee(); break;
                    case 2: ViewEmployee(); break;
                    case 3: ViewAll(); break;
                    case 4: UpdateEmp(); break;
                    case 5: DeleteEmp(); break;
                    case 6: return;
                }
            }
        }
        private static async void DeleteEmp() {
            Console.Write("Enter emp id to delete: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            EmployeeRepository empRepo = new EmployeeRepository();
            Employee emp = await empRepo.GetEmployeeById(eid);
            if (emp == null) {
                Console.WriteLine("No such emp id");
            }
            else {
                Console.WriteLine($"Name: {emp.EmpName}, Salary: {emp.Salary}");
                Console.Write("Are you sure to delete? ");
                char choice = Convert.ToChar(Console.ReadLine());
                if (choice == 'y') {
                    await empRepo.DeleteEmployee(eid);
                    Console.WriteLine("Employee deleted.");
                }
            }
        }
        private static async void UpdateEmp() {
            Console.Write("Enter emp id to update: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            EmployeeRepository empRepo = new EmployeeRepository();
            Employee emp = await empRepo.GetEmployeeById(eid);
            if (emp == null) {
                Console.WriteLine("No such emp id");
            }
            else {
                Console.WriteLine($"Name: {emp.EmpName}, Salary: {emp.Salary}");
                Console.Write("Enter new name: ");
                emp.EmpName = Console.ReadLine();
                Console.Write("Enter new salary: ");
                emp.Salary = Convert.ToDecimal(Console.ReadLine());
                await empRepo.UpdateEmployee(eid, emp);
                Console.WriteLine("Employee details updated.");
            }
        }
        private static async void ViewAll() {
            EmployeeRepository empRepo = new EmployeeRepository();
            ArrayList emps = await empRepo.GetAllEmployees();
            Console.WriteLine("List of employees...");
            foreach (Employee emp in emps) {
                Console.WriteLine($"Emp Id: {emp.EmpId}, Name: {emp.EmpName}, Salary: {emp.Salary}");
            }
        }
        private static async void ViewEmployee()  {
            Console.Write("Enter emp id to view: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            EmployeeRepository empRepo = new EmployeeRepository();
            Employee emp = await empRepo.GetEmployeeById(eid);
            if (emp == null)
                Console.WriteLine("No such emp id.");
            else
                Console.WriteLine($"Name: {emp.EmpName}, Salary: {emp.Salary}");
        }
        private static async void NewEmployee() {
            Employee emp = new Employee();
            Console.Write("Enter emp id: ");
            emp.EmpId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter name: ");
            emp.EmpName = Console.ReadLine();
            Console.Write("Enter salary: ");
            emp.Salary = Convert.ToDecimal(Console.ReadLine());
            EmployeeRepository empRepo = new EmployeeRepository();
            await empRepo.InsertEmployee(emp);
            Console.WriteLine("New employee added.");
        }
    }
}
