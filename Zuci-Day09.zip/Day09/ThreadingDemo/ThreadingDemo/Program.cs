﻿using System.Threading;
namespace ThreadingDemo { 
    internal class Program {
        static void PrintNumbers() {
            Console.WriteLine($"Thread ID of PrintNumbers is {Thread.CurrentThread.ManagedThreadId}");
            for (int i = 0; i < 100; i++) {
                Console.Write(i);
                Console.Write("\t");
            }
            Console.WriteLine();
        }
        static void Main(string[] args) {
            Console.WriteLine($"Thread ID of Main is {Thread.CurrentThread.ManagedThreadId}");
            Console.WriteLine("Calling PrintNumbers()...");
            //PrintNumbers();   // Synchronous call
            ThreadStart threadStart = new ThreadStart(PrintNumbers);
            Thread thread = new Thread(threadStart);
            thread.Start();     // Asynchronous call
            Console.WriteLine("PrintNumbers() finished.");
            Console.WriteLine("Main continues...");
        }
    }
}
