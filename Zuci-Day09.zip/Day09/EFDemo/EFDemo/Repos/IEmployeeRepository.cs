﻿using EFDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDemo.Repos
{
    public interface IEmployeeRepository
    {
        Task<List<Employee>> GetAllEmployees();
        Task<Employee> GetEmployeeById(int eid);
        Task InsertEmployee(Employee employee);
        Task UpdateEmployee(int eid, Employee employee);
        Task DeleteEmployee(int eid);
    }
}
