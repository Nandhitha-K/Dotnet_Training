﻿using EFDemo.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDemo.Repos
{
    public class EFEmployeeRepository : IEmployeeRepository {
        ZuciDBContext ctx = new ZuciDBContext();
        public async Task DeleteEmployee(int eid) {
            Employee emp2del = await GetEmployeeById(eid);
            ctx.Employees.Remove(emp2del);
            await ctx.SaveChangesAsync();
        }
        public async Task<List<Employee>> GetAllEmployees() {
            List<Employee> employees = await ctx.Employees.ToListAsync();
            return employees;
        }
        public async Task<Employee> GetEmployeeById(int eid) {
            try {
                Employee employee = await (from emp in ctx.Employees where emp.EmpId == eid select emp).FirstAsync();
                return employee;
            }
            catch (Exception) {
                throw new Exception("No such emp id");
            }
        }
        public async Task InsertEmployee(Employee employee) {
            await ctx.Employees.AddAsync(employee);
            await ctx.SaveChangesAsync();
        }
        public async Task UpdateEmployee(int eid, Employee employee) {
            Employee emp2edit = await GetEmployeeById(eid);
            emp2edit.EmpName = employee.EmpName;
            emp2edit.Salary = employee.Salary;
            emp2edit.DoBirth = employee.DoBirth;
            await ctx.SaveChangesAsync();
        }
    }
}
