﻿using EFInstituteLibray.Models;
using EFInstituteLibray.Repos;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace InstituteMvcApp.Models
{
    public class ForeignKeyHelper {
        public static async Task<List<SelectListItem>> GetCourseCodes()
        {
            List<SelectListItem> courseCodes = new List<SelectListItem>();
            ICourseRepo courseRepo = new CourseRepo();
            List<Course> courses = await courseRepo.GetAllCourses();
            foreach (Course course in courses) {
                courseCodes.Add(new SelectListItem { Text = course.CourseCode, Value = course.CourseCode });
            }
            return courseCodes;
        }
        public static async Task<List<SelectListItem>> GetBatchCodes() {
            List<SelectListItem> batchCodes = new List<SelectListItem>();
            IBatchRepo batchRepo = new BatchRepo();
            List<Batch> batches = await batchRepo.GetAllBatches();
            foreach (Batch batch in batches) {
                batchCodes.Add(new SelectListItem { Text = batch.BatchCode, Value = batch.BatchCode });
            }
            return batchCodes;
        }
    }
}
