﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFInstituteLibray.Models;
using EFInstituteLibray.Repos;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
namespace InstituteMvcApp.Controllers
{
    public class StudentController : Controller {
        IStudentRepo repo;
        public StudentController(IStudentRepo studentRepo) {
            repo = studentRepo;
        }
        public async Task<ActionResult> Index() {
            List<Student> students = await repo.GetAllStudents();
            return View(students);
        }
        public async Task<ActionResult> Details(string rno) {
            Student student = await repo.GetStudentByRNo(rno);
            return View(student);
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Student student) {
            try {
                await repo.InsertStudent(student);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Student/Edit/{rno}")]
        public async Task<ActionResult> Edit(string rno) {
            Student student = await repo.GetStudentByRNo(rno);
            return View(student);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Student/Edit/{rno}")]
        public async Task<ActionResult> Edit(string rno, Student student) {
            try {
                await repo.UpdateStudent(rno, student);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Student/Delete/{rno}")]
        public async Task<ActionResult> Delete(string rno) {
            Student student = await repo.GetStudentByRNo(rno);
            return View(student);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Student/Delete/{rno}")]
        public async Task<ActionResult> Delete(string rno, IFormCollection collection) {
            try {
                await repo.DeleteSudent(rno);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public async Task<ActionResult> GetByBatch(string bc) {
            try {
                List<Student> students = await repo.GetStudentsByBCode(bc);
                return View(students);
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
    }
}
