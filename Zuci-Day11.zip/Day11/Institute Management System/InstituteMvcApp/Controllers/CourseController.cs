﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFInstituteLibray.Models;
using EFInstituteLibray.Repos;
namespace InstituteMvcApp.Controllers
{
    public class CourseController : Controller {
        ICourseRepo repo;
        public CourseController(ICourseRepo courseRepo) {
            //repo = new CourseRepo();
            repo = courseRepo;
        }
        public async Task<ActionResult> Index() {
            List<Course> courses = await repo.GetAllCourses();
            return View(courses);
        }
        public async Task<ActionResult> Details(string cc) {
            Course course = await repo.GetCourseByCode(cc);
            return View(course);
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Course course) {
            try {
                await repo.InsertCourse(course);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Course/Edit/{cc}")]
        public async Task<ActionResult> Edit(string cc) {
            Course course = await repo.GetCourseByCode(cc);
            return View(course);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Course/Edit/{cc}")]
        public async Task<ActionResult> Edit(string cc, Course course) {
            try {
                await repo.UpdateCourse(cc, course);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Course/Delete/{cc}")]
        public async Task<ActionResult> Delete(string cc) {
            Course course = await repo.GetCourseByCode(cc);
            return View(course);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Course/Delete/{cc}")]
        public async Task<ActionResult> Delete(string cc, IFormCollection collection) {
            try {
                await repo.DeleteCourse(cc);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
    }
}
