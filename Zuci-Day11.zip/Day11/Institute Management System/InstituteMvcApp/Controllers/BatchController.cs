﻿using EFInstituteLibray.Models;
using EFInstituteLibray.Repos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InstituteMvcApp.Controllers
{
    public class BatchController : Controller {
        IBatchRepo repo;
        public BatchController(IBatchRepo batchRepo) {
            repo = batchRepo;
        }
        public async Task<ActionResult> Index() {
            List<Batch> batches = await repo.GetAllBatches();
            return View(batches);
        }
        public async Task<ActionResult> Details(string bc) {
            Batch batch = await repo.GetBatchByCode(bc);
            return View(batch);
        }
        public ActionResult Create() { 
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Batch batch) {
            try {
                await repo.InsertBatch(batch);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Batch/Edit/{bc}")]
        public async Task<ActionResult> Edit(string bc) {
            Batch batch = await repo.GetBatchByCode(bc);
            return View(batch);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Batch/Edit/{bc}")]
        public async Task<ActionResult> Edit(string bc, Batch batch) {
            try {
                await repo.UpdateBatch(bc, batch);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        [Route("Batch/Delete/{bc}")]
        public async Task<ActionResult> Delete(string bc) {
            Batch batch = await repo.GetBatchByCode(bc);
            return View(batch);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Batch/Delete/{bc}")]
        public async Task<ActionResult> Delete(string bc, IFormCollection collection) {
            try {
                await repo.DeleteBatch(bc);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public async Task<ActionResult> GetByCourse(string cc) {    //Template:List
            try {
                List<Batch> batches = await repo.GetBatchesByCCode(cc);
                return View(batches);
            }
            catch {
                return View();
            }
        }
    }
}
