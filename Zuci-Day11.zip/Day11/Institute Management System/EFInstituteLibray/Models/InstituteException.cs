﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibray.Models
{
    public class InstituteException : Exception
    {
        public InstituteException(string errMsg) : base(errMsg)
        {
                
        }
    }
}
