﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EFInstituteLibray.Models;

public partial class ZuciInstituteDbContext : DbContext
{
    public ZuciInstituteDbContext()
    {
    }

    public ZuciInstituteDbContext(DbContextOptions<ZuciInstituteDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Batch> Batches { get; set; }

    public virtual DbSet<Course> Courses { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("data source=(localdb)\\MSSQLLocalDB; database=ZuciInstituteDB; integrated security=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Batch>(entity =>
        {
            entity.HasKey(e => e.BatchCode).HasName("PK__Batch__B22ADA8FC4E83323");

            entity.ToTable("Batch");

            entity.Property(e => e.BatchCode)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CourseCode)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.StartDate).HasColumnType("datetime");

            entity.HasOne(d => d.CourseCodeNavigation).WithMany(p => p.Batches)
                .HasForeignKey(d => d.CourseCode)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Batch__CourseCod__38996AB5");
        });

        modelBuilder.Entity<Course>(entity =>
        {
            entity.HasKey(e => e.CourseCode).HasName("PK__Course__FC00E001711D617C");

            entity.ToTable("Course");

            entity.Property(e => e.CourseCode)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.CourseFee).HasColumnType("money");
            entity.Property(e => e.CourseTitle)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.RollNo).HasName("PK__Student__7886D5A064B4360B");

            entity.ToTable("Student");

            entity.Property(e => e.RollNo)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.BatchCode)
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.StudAddress)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.StudName)
                .HasMaxLength(20)
                .IsUnicode(false);

            entity.HasOne(d => d.BatchCodeNavigation).WithMany(p => p.Students)
                .HasForeignKey(d => d.BatchCode)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Student__BatchCo__3B75D760");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
