﻿using System;
using System.Collections.Generic;

namespace EFInstituteLibray.Models;

public partial class Batch
{
    public string BatchCode { get; set; } = null!;

    public string CourseCode { get; set; } = null!;

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public virtual Course CourseCodeNavigation { get; set; } = null!;

    public virtual ICollection<Student> Students { get; set; } = new List<Student>();
}
