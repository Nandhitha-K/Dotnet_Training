﻿using System;
using System.Collections.Generic;

namespace EFInstituteLibray.Models;

public partial class Student
{
    public string RollNo { get; set; } = null!;

    public string BatchCode { get; set; } = null!;

    public string StudName { get; set; } = null!;

    public string? StudAddress { get; set; }

    public virtual Batch BatchCodeNavigation { get; set; } = null!;
}
