﻿using System;
using System.Collections.Generic;

namespace EFInstituteLibray.Models;

public partial class Course
{
    public string CourseCode { get; set; } = null!;

    public string CourseTitle { get; set; } = null!;

    public int Duration { get; set; }

    public decimal? CourseFee { get; set; }

    public virtual ICollection<Batch> Batches { get; set; } = new List<Batch>();
}
