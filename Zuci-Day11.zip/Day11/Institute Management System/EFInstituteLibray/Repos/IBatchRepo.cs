﻿using EFInstituteLibray.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibray.Repos
{
    public interface IBatchRepo
    {
        Task<List<Batch>> GetAllBatches();
        Task<Batch> GetBatchByCode(string bc);
        Task<List<Batch>> GetBatchesByCCode(string cc);
        Task InsertBatch(Batch bch);
        Task UpdateBatch(string bc, Batch bch);
        Task DeleteBatch(string bc);
    }
}
