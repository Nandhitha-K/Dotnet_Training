﻿using EFInstituteLibray.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibray.Repos
{
    public interface ICourseRepo
    {
        Task<List<Course>> GetAllCourses();
        Task<Course> GetCourseByCode(string cc);
        Task InsertCourse(Course crs);
        Task UpdateCourse(string cc, Course crs);
        Task DeleteCourse(string cc);
    }
}
