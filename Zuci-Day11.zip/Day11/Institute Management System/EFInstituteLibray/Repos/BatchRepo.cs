﻿using EFInstituteLibray.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibray.Repos
{
    public class BatchRepo : IBatchRepo {
        ZuciInstituteDbContext ctx = new ZuciInstituteDbContext();
        public async Task DeleteBatch(string bc) {
            try {
                Batch bth2del = await GetBatchByCode(bc);
                ctx.Batches.Remove(bth2del);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public async Task<List<Batch>> GetAllBatches() {
            List<Batch> batches = await ctx.Batches.ToListAsync();
            return batches;
        }
        public async Task<Batch> GetBatchByCode(string bc) {
            try {
                Batch batch = await (from b in ctx.Batches where b.BatchCode == bc select b).FirstAsync();
                return batch;
            }
            catch (Exception) {
                throw new InstituteException("No such batch code");
            }
        }
        public async Task<List<Batch>> GetBatchesByCCode(string cc) {
            List<Batch> batches = await (from b in ctx.Batches where b.CourseCode == cc select b).ToListAsync();
            if (batches.Count == 0)
                throw new InstituteException("No batches for this coutrse");
            else
                return batches;
        }
        public async Task InsertBatch(Batch bch) {
            try {
                await ctx.Batches.AddAsync(bch);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public async Task UpdateBatch(string bc, Batch bch) {
            try {
                Batch bth2edit = await GetBatchByCode(bc);
                bth2edit.CourseCode = bch.CourseCode;
                bth2edit.StartDate = bch.StartDate;
                bth2edit.EndDate = bch.EndDate;
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
    }
}
