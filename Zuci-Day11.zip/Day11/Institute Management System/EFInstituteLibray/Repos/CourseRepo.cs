﻿using EFInstituteLibray.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibray.Repos
{
    public class CourseRepo : ICourseRepo {
        ZuciInstituteDbContext ctx = new ZuciInstituteDbContext();
        public async Task DeleteCourse(string cc) {
            try { 
                Course crs2del = await GetCourseByCode(cc);
                ctx.Courses.Remove(crs2del);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public async Task<List<Course>> GetAllCourses() {
            List<Course> courses = await ctx.Courses.ToListAsync();
            return courses;
        }
        public async Task<Course> GetCourseByCode(string cc) {
            try {
                Course course = await (from crs in ctx.Courses where crs.CourseCode == cc select crs).FirstAsync();
                return course;
            }
            catch (Exception) {
                throw new InstituteException("No such course code");
            }
        }
        public async Task InsertCourse(Course crs) {
            try {
                await ctx.Courses.AddAsync(crs);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public async Task UpdateCourse(string cc, Course crs){
            try {
                Course crs2edit = await GetCourseByCode(cc);
                crs2edit.CourseTitle = crs.CourseTitle;
                crs2edit.CourseFee = crs.CourseFee;
                crs2edit.Duration = crs.Duration;
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
    }
}
