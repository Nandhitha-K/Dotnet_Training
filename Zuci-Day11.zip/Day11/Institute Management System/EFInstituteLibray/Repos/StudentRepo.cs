﻿using EFInstituteLibray.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibray.Repos
{
    public class StudentRepo : IStudentRepo {
        ZuciInstituteDbContext ctx = new ZuciInstituteDbContext();
        public async Task DeleteSudent(string rno) {
            try {
                Student stud2del = await GetStudentByRNo(rno);
                ctx.Students.Remove(stud2del);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public async Task<List<Student>> GetAllStudents() {
            List<Student> students = await ctx.Students.ToListAsync();
            return students;
        }
        public async Task<Student> GetStudentByRNo(string rno) {
            try {
                Student student = await (from st in ctx.Students where st.RollNo == rno select st).FirstAsync();
                return student;
            }
            catch (Exception) {
                throw new InstituteException("No such roll no.,");
            }
        }
        public async Task<List<Student>> GetStudentsByBCode(string bc) {
            List<Student> students = await (from st in ctx.Students where st.BatchCode == bc select st).ToListAsync();
            if (students.Count == 0)
                throw new InstituteException("No students in this batch");
            else
                return students;
        }
        public async Task InsertStudent(Student std) {
            try {
                await ctx.Students.AddAsync(std);
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) {
                throw new InstituteException(ex.Message);
            }
        }
        public async Task UpdateStudent(string rno, Student std) {
            try {
                Student stud2edit = await GetStudentByRNo(rno);
                stud2edit.StudName = std.StudName;
                stud2edit.StudAddress = std.StudAddress;
                stud2edit.BatchCode = std.BatchCode;
                await ctx.SaveChangesAsync();
            }
            catch (Exception ex) { 
                throw new InstituteException(ex.Message);
            }
        }
    }
}
