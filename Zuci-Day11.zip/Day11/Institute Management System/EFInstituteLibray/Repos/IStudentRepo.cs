﻿using EFInstituteLibray.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFInstituteLibray.Repos
{
    public interface IStudentRepo
    {
        Task<List<Student>> GetAllStudents();
        Task<Student> GetStudentByRNo(string rno);
        Task<List<Student>> GetStudentsByBCode(string bc);
        Task InsertStudent(Student std);
        Task UpdateStudent(string rno, Student std);
        Task DeleteSudent(string rno);
    }
}
