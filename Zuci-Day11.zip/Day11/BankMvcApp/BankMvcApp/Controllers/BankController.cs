﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFBankLibrary.Models;
using EFBankLibrary.Repos;
using System.Threading.Tasks.Dataflow;
namespace BankMvcApp.Controllers
{
    public class BankController : Controller {
        IBankRepo repo = new EFBankRepo();
        // Template is List; Model class is SBAccount
        public ActionResult Index() {
            List<SBAccount> accounts = repo.GetAllAccounts();
            return View(accounts);
        }
        // Template is Details; Model class is SBAccount
        public ActionResult Details(string accno) {
            SBAccount account = repo.GetAccountDetails(accno);
            return View(account);
        }
        // Template is Create; Model class is SBAccount
        public ActionResult Create() {
            SBAccount account = new SBAccount();
            return View(account);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(SBAccount account) {
            try {
                repo.NewAccount(account);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        // Template is Create; Model class is SBTransactiuon
        public ActionResult Deposit(string accno) {
            SBTransaction transaction = new SBTransaction();
            transaction.AccountNumber = accno;
            transaction.TransactionDate = DateTime.Now;
            transaction.TransactionType = "D";
            return View(transaction);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Deposit(SBTransaction transaction) {
            try {
                repo.DepositAmount(transaction.AccountNumber, (decimal)transaction.Amount);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        // Template is Create; Model class is SBTransactiuon
        public ActionResult Withdraw(string accno) {
            SBTransaction transaction = new SBTransaction();
            transaction.AccountNumber = accno;
            transaction.TransactionDate = DateTime.Now;
            transaction.TransactionType = "W";
            return View(transaction);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Withdraw(SBTransaction transaction) {
            try {
                repo.WithdrawAmount(transaction.AccountNumber, (decimal)transaction.Amount);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        // Template is List; Model class is SBTransaction
        public ActionResult GetTransactions(string accno) {
            List<SBTransaction> transactions = repo.GetTransactions(accno);
            return View(transactions);
        }
    }
}
