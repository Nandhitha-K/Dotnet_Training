﻿CREATE DATABASE ZuciInstituteDB

USE ZuciInstituteDB

CREATE TABLE Course(
	CourseCode CHAR(4) PRIMARY KEY,
	CourseTitle VARCHAR(20) NOT NULL,
	Duration INT NOT NULL,
	CourseFee MONEY)

CREATE TABLE Batch(
	BatchCode CHAR(4) PRIMARY KEY,
	CourseCode CHAR(4) NOT NULL REFERENCES Course(CourseCode),
	StartDate DATETIME,
	EndDate DATETIME)

CREATE TABLE Student(
	RollNo CHAR(6) PRIMARY KEY,
	BatchCode CHAR(4) NOT NULL REFERENCES Batch(BatchCode),
	StudName VARCHAR(20) NOT NULL,
	StudAddress VARCHAR(30))
