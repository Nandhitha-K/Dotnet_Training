﻿-- Q1. A/C #, name, address, tran id, date, amount, tran type
Select SBAccount.AccountNumber, CustomerName, CustomerAddress, TransactionId, TransactionDate,
	Amount, TransactionType From SBAccount Join SBTransaction 
	ON SBAccount.AccountNumber = SBTransaction.AccountNumber
-- OR using Alias names
Select A.AccountNumber, CustomerName, CustomerAddress, TransactionId, TransactionDate,
	Amount, TransactionType From SBAccount A Join SBTransaction T
	ON A.AccountNumber = T.AccountNumber
-- Q2. Flight #, from city, to city, travel date, depart time, arrive time
USE ZuciAirlinesDB
Select F.FlightNo, FromCity, ToCity, TravelDate, DepartTime, ArriveTime
	From Flight F JOIN FlightSchedule FS
	ON F.FlightNo = FS.FlightNo
-- Q3. PNR no, flight no, travel date, passenger no, name, gender, age
Select RM.PNRNo, FlightNo, TravelDate, PassengerNo, PassengerName, Gender, Age
	From RESERVATIONMASTER RM JOIN RESERVATIONDETAIL RD
	ON RM.PNRNO = RD.PNRNO
-- Q4. Flight #, travel date, depart time, arrive time, pnr no, no. of passengers
Select FS.FlightNo, FS.TravelDate, DepartTime, ArriveTime, PNRNo, NoOfPassengers
	From FLIGHTSCHEDULE FS JOIN RESERVATIONMASTER RM
	ON FS.FLIGHTNO = RM.FLIGHTNO AND FS.TRAVELDATE = RM.TRAVELDATE
-- Q5. Flight #, from city, to city, travel date, depart time, arrive time, 
--		pnr no, no. of passengers
Select F.FlightNo, FromCity, ToCity, FS.TravelDate, DepartTime, ArriveTime,
	PNRNo, NoOfPassengers From Flight F JOIN FLIGHTSCHEDULE FS 
	ON F.FLIGHTNO = FS.FLIGHTNO JOIN RESERVATIONMASTER RM
	ON FS.FLIGHTNO = RM.FLIGHTNO AND FS.TRAVELDATE = RM.TRAVELDATE
-- Q6. Flight #, travel date, depart time, arrive time, pnr no, passenger no, name,
--		gender, age
Select FS.FlightNo, FS.TravelDate, DepartTime, ArriveTime, RM.PnrNo, PassengerNo,
	PassengerName, Gender, Age From FLIGHTSCHEDULE FS JOIN RESERVATIONMASTER RM
	ON FS.FLIGHTNO = RM.FLIGHTNO AND FS.TRAVELDATE = RM.TRAVELDATE JOIN RESERVATIONDETAIL RD
	ON RM.PNRNO = RD.PNRNO
-- Q7. Flight #, from city, to city, travel date, depart time, arrive time, pnr no,
--		passenger no, name, gender, age
Select F.FlightNo, FromCity, ToCity, FS.TravelDate, DepartTime, ArriveTime,
	RM.PNRNo, PassengerNo, PassengerName, Gender, Age From Flight F JOIN FLIGHTSCHEDULE FS 
	ON F.FLIGHTNO = FS.FLIGHTNO JOIN RESERVATIONMASTER RM
	ON FS.FLIGHTNO = RM.FLIGHTNO AND FS.TRAVELDATE = RM.TRAVELDATE
	JOIN RESERVATIONDETAIL RD ON RM.PNRNO = RD.PNRNO

-- Outer Join
Select F.FlightNo, FromCity, ToCity, TravelDate, DepartTime, ArriveTime
	From Flight F LEFT OUTER JOIN FlightSchedule FS
	ON F.FlightNo = FS.FlightNo
-- OR
Select F.FlightNo, FromCity, ToCity, TravelDate, DepartTime, ArriveTime
	From FLIGHTSCHEDULE FS RIGHT OUTER JOIN Flight F
	ON F.FlightNo = FS.FlightNo

EmpId	EmpName	MgrId
----------------------
101		A
102		B		101
103		C		101
104		D		101
105		E		102
106		F		102
.....
USE ZuciDB

CREATE TABLE Empl (
EmpId INT PRIMARY KEY,
EmpName VARCHAR(30) NOT NULL,
MgrId INT REFERENCES Empl(EmpId))

Output:
------
EmpName	MgrName
-------	-------
A	
B		A
C		A
D		A
E		B
F		B
.....

Select X.EmpName, Y.EmpName "MgrName"
From Empl X LEFT OUTER JOIN Empl Y
ON X.MgrId = Y.EmpId

