﻿-- Q1. Display flightno, travel date, depart time, arrive time for the flights flying from Chennai
Select FlightNo From Flight Where FromCity='Chennai'
select * from FlightSchedule where FlightNo='6E2345'
-- OR subquery
select * from FlightSchedule where FlightNo=(Select FlightNo From Flight Where FromCity='Chennai')
-- if subquery returns more than one value
select * from FlightSchedule where FlightNo IN (Select FlightNo From Flight Where FromCity='Chennai')
-- OR
select * from FlightSchedule where FlightNo = ANY (Select FlightNo From Flight Where
		FromCity='Chennai')

-- Q2. Display pnr no, flight no, travel date for the reservation where Ramesh Kumar is flying.
select PNRNo from RESERVATIONDETAIL where PASSENGERNAME='Ramesh Kumar'
select * from RESERVATIONMASTER where PNRNO='xxxx'
-- OR
select * from RESERVATIONMASTER where PNRNO=(select PNRNo from RESERVATIONDETAIL 
	where PASSENGERNAME='Ramesh Kumar')
-- if subquery returns more than one value
select * from RESERVATIONMASTER where PNRNO IN (select PNRNo from RESERVATIONDETAIL 
	where PASSENGERNAME='Ramesh Kumar')
