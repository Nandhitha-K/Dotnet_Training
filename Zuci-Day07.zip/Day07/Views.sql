﻿CREATE VIEW VEmp1 AS Select EmpId, EmpName From Employee

Select * from VEmp1

CREATE VIEW VEmp2 AS Select * from Employee Where Salary > 5000

Select * From VEmp2

CREATE VIEW VEmp3(EId, EName, Sal, HRA) AS Select EmpId, EmpName, Salary, Salary*0.25 From Employee
Select * from VEmp3

USE ZuciAirlinesDB

Create View VFlightFS AS Select F.FlightNo, FromCity, ToCity, TravelDate, DepartTime, ArriveTime
	From Flight F JOIN FlightSchedule FS
	ON F.FlightNo = FS.FlightNo

Select * From VFlightFS

USE ZuciDB

Create View VEmp4 AS Select * From VEmp3 Where Sal > 5000
Select * from VEmp4

Create Synonym Emp For Employee
Select * from Emp
