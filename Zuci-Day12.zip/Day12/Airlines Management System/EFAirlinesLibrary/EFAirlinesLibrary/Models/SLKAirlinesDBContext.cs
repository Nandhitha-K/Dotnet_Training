﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EFAirlinesLibrary.Models;

public partial class SLKAirlinesDBContext : DbContext
{
    public SLKAirlinesDBContext()
    {
    }

    public SLKAirlinesDBContext(DbContextOptions<SLKAirlinesDBContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Flight> Flights { get; set; }

    public virtual DbSet<FlightSchedule> FlightSchedules { get; set; }

    public virtual DbSet<ReservationDetail> ReservationDetails { get; set; }

    public virtual DbSet<ReservationMaster> ReservationMasters { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("data source=(localdb)\\MSSQLLocalDB; database=SLKAirlinesDB; integrated security=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Flight>(entity =>
        {
            entity.HasKey(e => e.FlightNo).HasName("PK__Flight__8A9E3D45B77EECE1");

            entity.ToTable("Flight");

            entity.Property(e => e.FlightNo)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.FromCity)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ToCity)
                .HasMaxLength(20)
                .IsUnicode(false);
        });

        modelBuilder.Entity<FlightSchedule>(entity =>
        {
            entity.HasKey(e => new { e.FlightNo, e.TravelDate }).HasName("PK__FlightSc__93C3A6EC0A9D6C5E");

            entity.ToTable("FlightSchedule");

            entity.Property(e => e.FlightNo)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.TravelDate).HasColumnType("datetime");
            entity.Property(e => e.ArriveTime).HasColumnType("datetime");
            entity.Property(e => e.DepartTime).HasColumnType("datetime");

            entity.HasOne(d => d.FlightNoNavigation).WithMany(p => p.FlightSchedules)
                .HasForeignKey(d => d.FlightNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__FlightSch__Fligh__38996AB5");
        });

        modelBuilder.Entity<ReservationDetail>(entity =>
        {
            entity.HasKey(e => new { e.PNRNo, e.PassengerNo }).HasName("PK__Reservat__EEFE4407F79961BA");

            entity.ToTable("ReservationDetail");

            entity.Property(e => e.PNRNo)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.FirstName)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.LastName)
                .HasMaxLength(20)
                .IsUnicode(false);

            entity.HasOne(d => d.PNRNoNavigation).WithMany(p => p.ReservationDetails)
                .HasForeignKey(d => d.PNRNo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reservati__PNRNo__3E52440B");
        });

        modelBuilder.Entity<ReservationMaster>(entity =>
        {
            entity.HasKey(e => e.PNRNo).HasName("PK__Reservat__4677517B8B08AE3D");

            entity.ToTable("ReservationMaster");

            entity.Property(e => e.PNRNo)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.FlightNo)
                .HasMaxLength(6)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.TravelDate).HasColumnType("datetime");

            entity.HasOne(d => d.FlightSchedule).WithMany(p => p.ReservationMasters)
                .HasForeignKey(d => new { d.FlightNo, d.TravelDate })
                .HasConstraintName("FK__ReservationMaste__3B75D760");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
