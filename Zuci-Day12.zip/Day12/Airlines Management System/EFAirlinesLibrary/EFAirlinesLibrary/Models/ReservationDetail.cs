﻿using System;
using System.Collections.Generic;

namespace EFAirlinesLibrary.Models;

public partial class ReservationDetail
{
    public string PNRNo { get; set; } = null!;

    public int PassengerNo { get; set; }

    public string FirstName { get; set; } = null!;

    public string? LastName { get; set; }

    public string? Gender { get; set; }

    public short? Age { get; set; }

    public virtual ReservationMaster PNRNoNavigation { get; set; } = null!;
}
