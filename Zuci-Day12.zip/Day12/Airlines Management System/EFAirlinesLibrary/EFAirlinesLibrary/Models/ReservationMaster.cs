﻿using System;
using System.Collections.Generic;

namespace EFAirlinesLibrary.Models;

public partial class ReservationMaster
{
    public string PNRNo { get; set; } = null!;

    public string? FlightNo { get; set; }

    public DateTime? TravelDate { get; set; }

    public int? NoOfPassengers { get; set; }

    public virtual FlightSchedule? FlightSchedule { get; set; }

    public virtual ICollection<ReservationDetail> ReservationDetails { get; set; } = new List<ReservationDetail>();
}
