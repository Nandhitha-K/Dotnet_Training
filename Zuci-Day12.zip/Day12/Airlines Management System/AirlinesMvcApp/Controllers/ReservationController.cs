﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
namespace AirlinesMvcApp.Controllers {
    public class ReservationController : Controller {
        IReservationMasterRepo masterRepo;
        IReservationDetailRepo detailRepo;
        public ReservationController(IReservationMasterRepo reservationMasterRepo, IReservationDetailRepo reservationDetailRepo) {
            masterRepo = reservationMasterRepo;
            detailRepo = reservationDetailRepo;
        }
        public async Task<ActionResult> Index() {
            List<ReservationMaster> masters = await masterRepo.GetAll();
            return View(masters);
        }
        public async Task<ActionResult> Details(string pnr) {
            ReservationMaster master = await masterRepo.GetReservationMaster(pnr);
            return View(master);
        }
        public ActionResult Create() {
            ReservationMaster master = new ReservationMaster();
            return View(master);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(ReservationMaster master) {
                await masterRepo.InsertReservationMaster(master);
                return RedirectToAction(nameof(Index));
        }
        [Route("Reservation/Edit/{pnr}")]
        public async Task<ActionResult> Edit(string pnr) {
            ReservationMaster master = await masterRepo.GetReservationMaster(pnr);
            return View(master);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Reservation/Edit/{pnr}")]
        public async Task<ActionResult> Edit(string pnr, ReservationMaster master) {
                await masterRepo.UpdateReservationMaster(pnr, master);
                return RedirectToAction(nameof(Index));
        }
        [Route("Reservation/Delete/{pnr}")]
        public async Task<ActionResult> Delete(string pnr) {
            ReservationMaster master = await masterRepo.GetReservationMaster(pnr);
            return View(master);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Reservation/Delete/{pnr}")]
        public async Task<ActionResult> Delete(string pnr, IFormCollection collection) {
                await masterRepo.DeleteReservationMaster(pnr);
                return RedirectToAction(nameof(Index));
        }
        // Template: List; Model class: ReservationDetail
        public async Task<ActionResult> Passengers(string pnr) {
            List<ReservationDetail> passengers = new List<ReservationDetail>();
            passengers = await detailRepo.GetReservationDetailsByPNR(pnr);
            return View(passengers);
        }
        // Template: Create; Model class: ReservationDetail
        public ActionResult CreatePassenger() {
            ReservationDetail passenger = new ReservationDetail();
            return View(passenger);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CreatePassenger(ReservationDetail passenger) {
                await detailRepo.InsertReservationDetail(passenger);
                return RedirectToAction(nameof(Passengers));
        }
        // Template: Details; Model class: ReservationDetail
        public async Task<ActionResult> PassengerDetails(string pnr, int pno) {
            ReservationDetail passenger = await detailRepo.GetReservationDetail(pnr, pno);
            return View(passenger);
        }
        // Template: Edit; Model class: ReservationDetail
        [Route("Reservation/EditPassenger/{pnr}/{pno}")]
        public async Task<ActionResult> EditPassenger(string pnr, int pno) {
            ReservationDetail passenger = await detailRepo.GetReservationDetail(pnr, pno);
            return View(passenger);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("Reservation/EditPassenger/{pnr}/{pno}")]
        public async Task<ActionResult> EditPassenger(string pnr, int pno, ReservationDetail detail){
                await detailRepo.UpdateReservationDetail(pnr, pno, detail);
                return RedirectToAction(nameof(Index));
        }

    }
}
