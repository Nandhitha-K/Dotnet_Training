﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
namespace AirlinesMvcApp.Controllers {
    public class FlightController : Controller {
        IFlightRepo flightRepo;
        public FlightController(IFlightRepo repo) {
            flightRepo = repo;
        }
        public async Task<ActionResult> Index() {
            List<Flight> flights = await flightRepo.GetAllFlights();
            return View(flights);
        }
        public ActionResult Details(int id) {
            return View();
        }
        public ActionResult Create() {
            Flight flight = new Flight();
            return View(flight);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Flight flight) {
                await flightRepo.InsertFlight(flight);
                return RedirectToAction(nameof(Index));
        }
        public ActionResult Edit(int id)
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
                return RedirectToAction(nameof(Index));
        }
        public ActionResult Delete(int id)
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
                return RedirectToAction(nameof(Index));
        }
    }
}
