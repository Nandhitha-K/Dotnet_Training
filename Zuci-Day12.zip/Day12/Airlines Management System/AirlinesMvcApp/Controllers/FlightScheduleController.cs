﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EFAirlinesLibrary.Models;
using EFAirlinesLibrary.Repos;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AirlinesMvcApp.Controllers {
    public class FlightScheduleController : Controller {
        IFlightScheduleRepo scheduleRepo;
        public FlightScheduleController(IFlightScheduleRepo repo) {
            scheduleRepo = repo;
        }
        public static async Task<List<SelectListItem>> GetFlightNos()
        {
            IFlightRepo flightRepo = new EFFlightRepo();
            List<Flight> flights = await flightRepo.GetAllFlights();
            List<SelectListItem> fnos = new List<SelectListItem>();
            foreach (Flight flight in flights)
            {
                fnos.Add(new SelectListItem() { Text = flight.FlightNo, Value = flight.FlightNo });
            }
            return fnos;
        }
        public async Task<ActionResult> Index() {
            List<FlightSchedule> schedules = await scheduleRepo.GetAllSchedules();
            return View(schedules);
        }
        public async Task<ActionResult> Details(string fno, DateTime tdate) {
            FlightSchedule fs = await scheduleRepo.GetSchedule(fno, tdate);
            return View(fs);
        }
        public ActionResult Create() {
            FlightSchedule schedule = new FlightSchedule();
            return View(schedule);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(FlightSchedule schedule) {
                await scheduleRepo.InsertSchedule(schedule);
                return RedirectToAction(nameof(Index));
        }
        [Route("FlightSchedule/Edit/{fno}/{tdate}")]
        public async Task<ActionResult> Edit(string fno, DateTime tdate) {
            FlightSchedule fs = await scheduleRepo.GetSchedule(fno, tdate);
            return View(fs);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("FlightSchedule/Edit/{fno}/{tdate}")]
        public async Task<ActionResult> Edit(string fno, DateTime tdate, FlightSchedule schedule) {
            await scheduleRepo.UpdateSchedule(fno, tdate, schedule);
            return RedirectToAction(nameof(Index));
        }
        [Route("FlightSchedule/Delete/{fno}/{tdate}")]
        public async Task<ActionResult> Delete(string fno, DateTime tdate) {
            FlightSchedule fs = await scheduleRepo.GetSchedule(fno, tdate);
            return View(fs);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Route("FlightSchedule/Delete/{fno}/{tdate}")]
        public async Task<ActionResult> Delete(string fno, DateTime tdate, IFormCollection collection) {
            await scheduleRepo.DeleteSchedule(fno, tdate);
            return RedirectToAction(nameof(Index));
        }
    }
}
