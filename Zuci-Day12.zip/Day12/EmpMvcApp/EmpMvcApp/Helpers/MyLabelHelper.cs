﻿using Microsoft.AspNetCore.Html;

namespace EmpMvcApp.Helpers
{
    public class MyLabelHelper
    {
        public static HtmlString MyLabel(string target, string text)
        {
            string str = $"<LABEL FOR='{target}'>{text}</LABEL>";
            return new HtmlString(str);
        }
    }
}
