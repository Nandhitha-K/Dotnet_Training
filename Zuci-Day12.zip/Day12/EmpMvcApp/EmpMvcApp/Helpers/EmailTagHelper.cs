﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace EmpMvcApp.Helpers
{
    public class EmailTagHelper : TagHelper
    {
        public string MailTo { get; set; }
        private const string EmailDomain = "zuci.com";
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "A";
            var address = MailTo + "@" + EmailDomain;
            output.Attributes.SetAttribute("href", "mailto:" + address);
            output.Content.SetContent(address);
        }
    }
}
