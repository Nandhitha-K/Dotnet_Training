﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.Text.Encodings.Web;
using System.Web;

namespace EmpMvcApp.Helpers
{
    public static class MyImageHelper
    {
        public static HtmlString MyImage(this IHtmlHelper hh, string id, string path, string altText, object attributes=null)
        {
            TagBuilder tag = new TagBuilder("IMG");
            tag.GenerateId("ID", id);
            tag.MergeAttribute("SRC", path);
            tag.MergeAttribute("ALT", altText);
            tag.MergeAttributes(new RouteValueDictionary(attributes));
            tag.TagRenderMode = TagRenderMode.SelfClosing;
            StringWriter writer = new StringWriter();
            tag.WriteTo(writer, HtmlEncoder.Default);
            return new HtmlString(writer.ToString());
        }
    }
}
