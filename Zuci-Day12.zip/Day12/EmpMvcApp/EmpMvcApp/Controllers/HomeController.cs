using EmployeeLibrary;
using EmpMvcApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using System.Diagnostics;
using EmpMvcApp.Filters;

namespace EmpMvcApp.Controllers
{
    //[LogActionFilter]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        //[LogActionFilter]
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public ActionResult GetNewEmployee()
        {
            Employee emp = new Employee { EmpId = 999, EmpName = "Arjun", Salary = 6500 };
            return Json(emp);
        }
        [NonAction]
        public ActionResult GetSecret()
        {
            return Content("This is the secret");
        }
        [OutputCache(Duration = 10)]
        public ActionResult GetServerTime()
        {
            string time = DateTime.Now.ToLongTimeString();
            return Content(time);
        }
    }
}
