﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EmployeeLibrary;
namespace EmpMvcApp.Controllers { 
    public class EmployeeController : Controller {
        EmployeeRepository repo = new EmployeeRepository();
        public async Task<ActionResult> Index() {
            List<Employee> employees = await repo.GetAllEmployees();
            return View(employees);
        }
        public async Task<ActionResult> Details(int id) {
            Employee employee = await repo.GetEmployeeById(id);
            return View(employee);
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Employee employee) {
                /*if (employee.Salary <= 0)
                    ModelState.AddModelError("Salary", "Salary must be above zero");*/
                if (!ModelState.IsValid)
                    return View();
                await repo.InsertEmployee(employee);
                return RedirectToAction(nameof(Index));
        }
        public ActionResult Edit(int id) {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection) {
            return RedirectToAction(nameof(Index));
        }
        public ActionResult Delete(int id) {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection) {
            return RedirectToAction(nameof(Index));
        }
    }
}
