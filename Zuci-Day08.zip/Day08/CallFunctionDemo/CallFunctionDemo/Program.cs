﻿using Microsoft.Data.SqlClient;

namespace CallFunctionDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            Console.Write("Enter a number: ");
            int num = Convert.ToInt32(Console.ReadLine());
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "FACTORIAL";
            cmd.Parameters.AddWithValue("@NUM", num);
            SqlParameter pfact = new SqlParameter();
            pfact.SqlDbType = System.Data.SqlDbType.BigInt;
            pfact.Direction = System.Data.ParameterDirection.ReturnValue;
            pfact.Value = num;
            cmd.Parameters.Add(pfact);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Console.WriteLine($"Factorial = {pfact.Value}");
        }
    }
}
