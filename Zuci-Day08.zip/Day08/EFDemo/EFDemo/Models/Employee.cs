﻿using System;
using System.Collections.Generic;

namespace EFDemo.Models;

public partial class Employee
{
    public int EmpId { get; set; }

    public string? EmpName { get; set; }

    public decimal? Salary { get; set; }

    public DateOnly? DoBirth { get; set; }
}
