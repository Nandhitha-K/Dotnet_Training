﻿using EFDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDemo.Repos
{
    public class EFEmployeeRepository : IEmployeeRepository {
        ZuciDBContext ctx = new ZuciDBContext();
        public void DeleteEmployee(int eid) {
            Employee emp2del = GetEmployeeById(eid);
            ctx.Employees.Remove(emp2del);
            ctx.SaveChanges();
        }
        public List<Employee> GetAllEmployees() {
            List<Employee> employees = ctx.Employees.ToList();
            return employees;
        }
        public Employee GetEmployeeById(int eid) {
            try {
                Employee employee = (from emp in ctx.Employees where emp.EmpId == eid select emp).First();
                return employee;
            }
            catch (Exception) {
                throw new Exception("No such emp id");
            }
        }
        public void InsertEmployee(Employee employee) {
            ctx.Employees.Add(employee);
            ctx.SaveChanges();
        }
        public void UpdateEmployee(int eid, Employee employee) {
            Employee emp2edit = GetEmployeeById(eid);
            emp2edit.EmpName = employee.EmpName;
            emp2edit.Salary = employee.Salary;
            emp2edit.DoBirth = employee.DoBirth;
            ctx.SaveChanges();
        }
    }
}
