﻿DECLARE @NUM INT
SET @NUM=1
WHILE @NUM <= 10
BEGIN
  PRINT @NUM
  SET @NUM=@NUM+1
END

-- Calculate the factorial of a number
