﻿using Microsoft.Data.SqlClient;
namespace CallSPDemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            Console.Write("Enter emp id: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "GetEmpDetails";
            cmd.Parameters.AddWithValue("@EID", eid);
            SqlParameter pename = new SqlParameter();
            pename.ParameterName = "@ENAME";
            pename.SqlDbType = System.Data.SqlDbType.VarChar;
            pename.Size = 40;
            pename.Direction = System.Data.ParameterDirection.Output;
            cmd.Parameters.Add(pename);
            SqlParameter psal = new SqlParameter();
            psal.ParameterName = "@SAL";
            psal.SqlDbType = System.Data.SqlDbType.Money;
            psal.Direction = System.Data.ParameterDirection.Output;
            cmd.Parameters.Add(psal);
            SqlParameter pdob = new SqlParameter();
            pdob.ParameterName = "@DOB";
            pdob.SqlDbType = System.Data.SqlDbType.Date;
            pdob.Direction = System.Data.ParameterDirection.Output;
            cmd.Parameters.Add(pdob);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            string ename = (string)pename.Value;
            decimal sal = (decimal)psal.Value;
            DateTime dob = (DateTime)pdob.Value;
            Console.WriteLine($"Name: {ename}, Salary: {sal}, DoBirth: {dob}");
        }
    }
}
