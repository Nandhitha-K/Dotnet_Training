﻿using Microsoft.Data.SqlClient;

namespace CallSPDemo
{
    internal class Program
    {
        static void Main(string[] args) {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            Console.Write("Enter emp id: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter name: ");
            string ename = Console.ReadLine();
            Console.Write("Enter salary: ");
            decimal sal = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Enter date of birth: ");
            DateTime dob = Convert.ToDateTime(Console.ReadLine());

            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "ADDEMP";
            cmd.Parameters.AddWithValue("@EID", eid);
            cmd.Parameters.AddWithValue("@ENAME", ename);
            cmd.Parameters.AddWithValue("@SAL", sal);
            cmd.Parameters.AddWithValue("@DOB", dob);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Console.WriteLine("New employee added.");
        }
    }
}
