﻿using AirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlinesLibrary.Repos
{
    public class ADOReservationMasterRepo : IReservationMasterRepo {
        SqlConnection con;
        SqlCommand cmd;
        public ADOReservationMasterRepo() {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSqlLocalDB; database=ZuciAirlinesDB; integrated security=true";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteReservationMaster(string pnr) {
            cmd.CommandText = "DELETE FROM ReservationMaster WHERE PNRNo = '" + pnr + "'";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public List<ReservationMaster> GetAllReservationMasters() {
            cmd.CommandText = "SELECT * FROM ReservationMaster";
            List<ReservationMaster> masters = new List<ReservationMaster>();
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read()) {
                ReservationMaster master = new ReservationMaster();
                master.PNRNo = (string)reader["PNRNo"];
                master.FlightNo = (string)reader["FlightNo"];
                master.TravelDate = (DateOnly)reader["TravelDate"];
                master.NoOfPassengers = (int)reader["NoOfPassengers"];
                masters.Add(master);
            }
            con.Close();
            return masters;
        }
        public ReservationMaster GetReservationMaster(string pnr) {
            cmd.CommandText = "SELECT * FROM ReservationMaster WHERE PNRNo = '" + pnr + "'";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows) {
                reader.Read();
                ReservationMaster master = new ReservationMaster();
                master.PNRNo = (string)reader["PNRNo"];
                master.FlightNo = (string)reader["FlightNo"];
                master.TravelDate = (DateOnly)reader["TravelDate"];
                master.NoOfPassengers = (int)reader["NoOfPassengers"];
                con.Close();
                return master;
            }
            else {
                con.Close();
                throw new AirlinesException("No such PNR no.");
            }
        }
        public List<ReservationMaster> GetMastersByFlight(string fno, DateOnly trdate) {
            cmd.CommandText = "SELECT * FROM ReservationMaster WHERE FlightNo = '" + fno + "' AND TravelDate = '" + trdate + "'";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows) {
                List<ReservationMaster> masters = new List<ReservationMaster>();
                while (reader.Read()) {
                    ReservationMaster master = new ReservationMaster();
                    master.PNRNo = (string)reader["PNRNo"];
                    master.FlightNo = (string)reader["FlightNo"];
                    master.TravelDate = (DateOnly)reader["TravelDate"];
                    master.NoOfPassengers = (int)reader["NoOfPassengers"];
                    masters.Add(master);
                }
                con.Close();
                return masters;
            }
            else {
                con.Close();
                throw new AirlinesException("No reservations done for this flight on this date");
            }
        }
        public void InsertReservationMaster(ReservationMaster master) {
            cmd.CommandText = "INSERT INTO ReservationMaster VALUES(@PNR, @FNO, @TRDATE, @NOP)";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@PNR", master.PNRNo);
            cmd.Parameters.AddWithValue("@FNO", master.FlightNo);
            cmd.Parameters.AddWithValue("@TRDATE", master.TravelDate);
            cmd.Parameters.AddWithValue("@NOP", master.NoOfPassengers);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void UpdateReservationMaster(string pnr, ReservationMaster master) {
            cmd.CommandText = "UPDATE ReservationMaster SET FlightNo=@FNO, TravelDate=@TRDATE, NoOfPassengers=@NOP WHERE PNRNo = @PNR";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@PNR", master.PNRNo);
            cmd.Parameters.AddWithValue("@FNO", master.FlightNo);
            cmd.Parameters.AddWithValue("@TRDATE", master.TravelDate);
            cmd.Parameters.AddWithValue("@NOP", master.NoOfPassengers);
            con.Close();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
