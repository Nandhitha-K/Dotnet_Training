﻿using AirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlinesLibrary.Repos
{
    public interface IFlightScheduleRepo
    {
        List<FlightSchedule> GetAllSchedules();
        FlightSchedule GetSchedule(string fno, DateOnly tdate);
        List<FlightSchedule> GetSchedulesByFlightNo(string fno);
        List<FlightSchedule> GetSchedulesByTravelDate(DateOnly tdate);
        void InsertSchedule(FlightSchedule schedule);
        void UpdateSchedule(string fno, DateOnly tdate, FlightSchedule schedule);
        void DeleteSchedule(string fno, DateOnly tdate);
    }
}
