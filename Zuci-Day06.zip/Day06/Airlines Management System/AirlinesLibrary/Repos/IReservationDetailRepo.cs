﻿using AirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlinesLibrary.Repos
{
    public interface IReservationDetailRepo
    {
        List<ReservationDetail> GetAllReservationDetails();
        ReservationDetail GetReservationDetail(string pnr, int pno);
        List<ReservationDetail> GetDetailsByPnr(string pnr);
        void InsertReservationDetail(ReservationDetail detail);
        void UpdateReservationDetail(string pnr, int pno, ReservationDetail detail);
        void DeleteReservationDetail(string pnr, int pno);
    }
}
