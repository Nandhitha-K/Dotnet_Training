﻿using AirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlinesLibrary.Repos
{
    public interface IReservationMasterRepo
    {
        List<ReservationMaster> GetAllReservationMasters();
        ReservationMaster GetReservationMaster(string pnr);
        List<ReservationMaster> GetMastersByFlight(string fno, DateOnly tdate);
        void InsertReservationMaster(ReservationMaster master);
        void UpdateReservationMaster(string pnr, ReservationMaster master);
        void DeleteReservationMaster(string pnr);
    }
}
