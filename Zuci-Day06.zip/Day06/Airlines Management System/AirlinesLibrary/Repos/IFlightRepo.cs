﻿using AirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlinesLibrary.Repos
{
    public interface IFlightRepo
    {
        List<Flight> GetAllFlights();
        Flight GetFlightByNo(string fno);
        void InsertFlight(Flight flight);
        void UpdateFlight(string fno, Flight flight);
        void DeleteFlight(string fno);
    }
}
