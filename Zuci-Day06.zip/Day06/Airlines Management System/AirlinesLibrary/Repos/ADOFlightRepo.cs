﻿using AirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace AirlinesLibrary.Repos {
    public class ADOFlightRepo : IFlightRepo {
        SqlConnection con;
        SqlCommand cmd;
        public ADOFlightRepo() {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciAirlinesDB; integrated security=true";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteFlight(string fno) {
            cmd.CommandText = "DELETE FROM FLIGHT WHERE FLIGHTNO = '" + fno + "'";
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public List<Flight> GetAllFlights() {
            cmd.CommandText = "SELECT * FROM FLIGHT";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            List<Flight> flights = new List<Flight>();
            while (drdr.Read()) {
                Flight flight = new Flight();
                flight.FlightNo = (string)drdr["FlightNo"];
                flight.FromCity = (string)drdr["FromCity"];
                flight.ToCity = (string)drdr["ToCity"];
                flight.TotalSeats = (int)drdr["TotalSeats"];
                flights.Add(flight);
            }
            con.Close();
            return flights;
        }
        public Flight GetFlightByNo(string fno) {
            cmd.CommandText = "SELECT * FROM FLIGHT WHERE FLIGHTNO = '" + fno + "'";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            if (drdr.HasRows) {
                drdr.Read();
                Flight flight = new Flight();
                flight.FlightNo = (string)drdr["FlightNo"];
                flight.FromCity = (string)drdr["FromCity"];
                flight.ToCity = (string)drdr["ToCity"];
                flight.TotalSeats = (int)drdr["TotalSeats"];
                con.Close();
                return flight;
            }
            else {
                con.Close();
                throw new AirlinesException("No such flight no.");
            }
        }
        public void InsertFlight(Flight flight) {
            cmd.CommandText = "INSERT INTO FLIGHT VALUES(@FNO, @FCITY, @TCITY, @TOTSEATS)";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@FNO", flight.FlightNo);
            cmd.Parameters.AddWithValue("@FCITY", flight.FromCity);
            cmd.Parameters.AddWithValue("@TCITY", flight.ToCity);
            cmd.Parameters.AddWithValue("@TOTSEATS", flight.TotalSeats);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void UpdateFlight(string fno, Flight flight) {
            cmd.CommandText = "UPDATE FLIGHT SET FROMCITY=@FCITY, TOCITY=@TCITY, TOTALSEATS=@TOTSEATS WHERE FLIGHTNO=@FNO";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@FNO", flight.FlightNo);
            cmd.Parameters.AddWithValue("@FCITY", flight.FromCity);
            cmd.Parameters.AddWithValue("@TCITY", flight.ToCity);
            cmd.Parameters.AddWithValue("@TOTSEATS", flight.TotalSeats);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
