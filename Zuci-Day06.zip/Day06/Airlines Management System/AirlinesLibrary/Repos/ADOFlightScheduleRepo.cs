﻿using AirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlinesLibrary.Repos
{
    public class ADOFlightScheduleRepo : IFlightScheduleRepo {
        SqlConnection con;
        SqlCommand cmd;
        public ADOFlightScheduleRepo() { 
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciAirlinesDB; integrated security=true";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteSchedule(string fno, DateOnly tdate) {
            cmd.CommandText = "DELETE FROM FLIGHTSCHEDULE WHERE FLIGHTNO=@FNO AND TRAVELDATE=@TDATE";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@FNO", fno);
            cmd.Parameters.AddWithValue("@TDATE", tdate);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public List<FlightSchedule> GetAllSchedules() {
            cmd.CommandText = "SELECT * FROM FLIGHTSCHEDULE";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            List<FlightSchedule> schedules = new List<FlightSchedule>();
            while (drdr.Read()) {
                FlightSchedule schedule = new FlightSchedule();
                schedule.FlightNo = (string)drdr["FlightNo"];
                schedule.TravelDate = (DateOnly)drdr["TravelDate"];
                schedule.DepartTime = (DateTime)drdr["DepartTime"];
                schedule.ArriveTime = (DateTime)drdr["ArriveTime"];
                schedules.Add(schedule);
            }
            con.Close();
            return schedules;
        }
        public FlightSchedule GetSchedule(string fno, DateOnly tdate) {
            cmd.CommandText = "SELECT * FROM FLIGHTSCHEDULE WHERE FLIGHTNO=@FNO AND TRAVELDATE=@TDATE";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@FNO", fno);
            cmd.Parameters.AddWithValue("@TDATE", tdate);
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            if (drdr.HasRows) {
                drdr.Read();
                FlightSchedule schedule = new FlightSchedule();
                schedule.FlightNo = (string)drdr["FlightNo"];
                schedule.TravelDate = (DateOnly)drdr["TravelDate"];
                schedule.DepartTime = (DateTime)drdr["DepartTime"];
                schedule.ArriveTime = (DateTime)drdr["ArriveTime"];
                con.Close();
                return schedule;
            }
            else {
                con.Close();
                throw new AirlinesException("No such flight scheduled on this date");
            }
        }
        public List<FlightSchedule> GetSchedulesByFlightNo(string fno) {
            cmd.CommandText = "SELECT * FROM FLIGHTSCHEDULE WHERE FLIGHTNO = '" + fno + "'";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            if (drdr.HasRows) {
                List<FlightSchedule> schedules = new List<FlightSchedule>();
                while (drdr.Read()) {
                    FlightSchedule schedule = new FlightSchedule();
                    schedule.FlightNo = (string)drdr["FlightNo"];
                    schedule.TravelDate = (DateOnly)drdr["TravelDate"];
                    schedule.DepartTime = (DateTime)drdr["DepartTime"];
                    schedule.ArriveTime = (DateTime)drdr["ArriveTime"];
                    schedules.Add(schedule);
                }
                con.Close();
                return schedules;
            }
            else {
                con.Close();
                throw new AirlinesException("This flight is net yet scheduled.");
            }
        }
        public List<FlightSchedule> GetSchedulesByTravelDate(DateOnly tdate) {
            cmd.CommandText = "SELECT * FROM FLIGHTSCHEDULE WHERE TRAVELDATE = '" + tdate + "'";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            if (drdr.HasRows) {
                List<FlightSchedule> schedules = new List<FlightSchedule>();
                while (drdr.Read()) {
                    FlightSchedule schedule = new FlightSchedule();
                    schedule.FlightNo = (string)drdr["FlightNo"];
                    schedule.TravelDate = (DateOnly)drdr["TravelDate"];
                    schedule.DepartTime = (DateTime)drdr["DepartTime"];
                    schedule.ArriveTime = (DateTime)drdr["ArriveTime"];
                    schedules.Add(schedule);
                }
                con.Close();
                return schedules;
            }
            else {
                con.Close();
                throw new AirlinesException("No flights scheduled on this date.");
            }
        }
        public void InsertSchedule(FlightSchedule schedule) { 
            cmd.CommandText = "INSERT INTO FLIGHTSCHEDULE VALUES(@FNO, @TDATE, @DTIME, @ATIME)";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@FNO", schedule.FlightNo);
            cmd.Parameters.AddWithValue("@TDATE", schedule.TravelDate);
            cmd.Parameters.AddWithValue("@DTIME", schedule.DepartTime);
            cmd.Parameters.AddWithValue("@ATIME", schedule.ArriveTime);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void UpdateSchedule(string fno, DateOnly tdate, FlightSchedule schedule) {
            cmd.CommandText = "UPDATE FLIGHTSCHEDULE SET DEPARTTIME=@DTIME, ARRIVETIME=@ATIME WHERE FLIGHTNO=@FNO AND TRAVELDATE=@TDATE";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@FNO", schedule.FlightNo);
            cmd.Parameters.AddWithValue("@TDATE", schedule.TravelDate);
            cmd.Parameters.AddWithValue("@DTIME", schedule.DepartTime);
            cmd.Parameters.AddWithValue("@ATIME", schedule.ArriveTime);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
