﻿using AirlinesLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlinesLibrary.Repos
{
    public class ADOReservationDetailRepo : IReservationDetailRepo {
        SqlConnection con;
        SqlCommand cmd;
        public ADOReservationDetailRepo() {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSqlLocalDB; database=ZuciAirlinesDB; integrated security=true";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteReservationDetail(string pnr, int pno) {
            cmd.CommandText = "DELETE FROM ReservationDetail WHERE PNRNo = '" + pnr + "'" + " AND PassengerNo = " + pno;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public List<ReservationDetail> GetAllReservationDetails() {
            cmd.CommandText = "SELECT * FROM ReservationDetail";
            List<ReservationDetail> details = new List<ReservationDetail>();
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read()) {
                ReservationDetail detail = new ReservationDetail();
                detail.PNRNo = (string)reader["PNRNo"];
                detail.PassengerNo = (int)reader["PassengerNo"];
                detail.PassengerName = (string)reader["PassengerName"];
                detail.Gender = (string)reader["Gender"];
                detail.Age = (int)reader["Age"];
                details.Add(detail);
            }
            con.Close();
            return details;
        }
        public ReservationDetail GetReservationDetail(string pnr, int pno) {
            cmd.CommandText = "SELECT * FROM ReservationDetail WHERE PNRNo = '" + pnr + "' AND PassengerNo = " + pno;
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows) {
                reader.Read();
                ReservationDetail detail = new ReservationDetail();
                detail.PNRNo = (string)reader["PNRNo"];
                detail.PassengerNo = (int)reader["PassengerNo"];
                detail.PassengerName = (string)reader["PassengerName"];
                detail.Gender = (string)reader["Gender"];
                detail.Age = (int)reader["Age"];
                con.Close();
                return detail;
            }
            else {
                con.Close();
                throw new AirlinesException("No such PNR or no such passenger no. for the PNR");
            }
        }
        public List<ReservationDetail> GetDetailsByPnr(string pnr) {
            cmd.CommandText = "SELECT * FROM ReservationDetail WHERE PNRNo = '" + pnr + "'";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows) {
                List<ReservationDetail> details = new List<ReservationDetail>();
                while (reader.Read()) {
                    ReservationDetail detail = new ReservationDetail();
                    detail.PNRNo = (string)reader["PNRNo"];
                    detail.PassengerNo = (int)reader["PassengerNo"];
                    detail.PassengerName = (string)reader["PassengerName"];
                    detail.Gender = (string)reader["Gender"];
                    detail.Age = (int)reader["Age"];
                    details.Add(detail);
                }
                con.Close();
                return details;
            }
            else {
                con.Close();
                throw new AirlinesException("No passenger details for this PNR");
            }
        }
        public void InsertReservationDetail(ReservationDetail detail) {
            cmd.CommandText = "INSERT INTO ReservationDetail VALUES(@PNR, @PNO, @PNAME, @GENDER, @AGE)";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@PNR", detail.PNRNo);
            cmd.Parameters.AddWithValue("@PNO", detail.PassengerNo);
            cmd.Parameters.AddWithValue("@PNAME", detail.PassengerName);
            cmd.Parameters.AddWithValue("@GENDER", detail.Gender);
            cmd.Parameters.AddWithValue("@AGE", detail.Age);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void UpdateReservationDetail(string pnr, int pno, ReservationDetail detail) {
            cmd.CommandText = "UPDATE ReservationDetail SET PassengerName=@PNAME, Gender=@GENDER, Age=@AGE WHERE PNRNo=@PNR AND PassengerNo=@PNO";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@PNR", pnr);
            cmd.Parameters.AddWithValue("@PNO", pno);
            cmd.Parameters.AddWithValue("@PNAME", detail.PassengerName);
            cmd.Parameters.AddWithValue("@GENDER", detail.Gender);
            cmd.Parameters.AddWithValue("@AGE", detail.Age);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
