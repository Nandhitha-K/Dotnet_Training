﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlinesLibrary.Models
{
    public class FlightSchedule
    {
        public string FlightNo { get; set; }
        public DateOnly TravelDate { get; set; }
        public DateTime DepartTime { get; set; }
        public DateTime ArriveTime { get; set; }
    }
}
