﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlinesLibrary.Models
{
    public class ReservationMaster
    {
        public string PNRNo { get; set; }
        public string FlightNo { get; set; }
        public DateOnly TravelDate { get; set; }
        public int NoOfPassengers { get; set; }
    }
}
