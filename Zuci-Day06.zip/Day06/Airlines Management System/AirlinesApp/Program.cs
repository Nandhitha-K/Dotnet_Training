﻿namespace AirlinesApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
           while(true)
            {
                Console.WriteLine("---Main Menu---");
                Console.WriteLine("1. Flight");
                Console.WriteLine("2. Flight Schedule");
                Console.WriteLine("3. Reservation");
                Console.WriteLine("4. Quit");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1: FlightMenu(); break;
                    case 2: FlightScheduleMenu(); break;
                    case 3: ReservationMenu(); break;
                    case 4: return;
                }
            }
        }

        private static void FlightMenu()
        {
            while(true)
            {
                Console.WriteLine("---Flight Menu---");
                Console.WriteLine("1. Add Flight");
            }
        }
    }
}
