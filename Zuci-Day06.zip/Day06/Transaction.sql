﻿-- Deposit Rs.4000/-
BEGIN TRANSACTION
INSERT INTO SBTransaction VALUES(GETDATE(), '100002', 4000, 'D')
UPDATE SBAccount SET CurrentBalance=CurrentBalance+4000 WHERE AccountNumber='100002'

COMMIT TRANSACTION

