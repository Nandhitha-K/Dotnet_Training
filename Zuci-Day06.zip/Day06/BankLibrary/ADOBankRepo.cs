﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Transactions;
namespace BankLibrary {
    public class ADOBankRepo : IBankRepo {
        SqlConnection con;
        SqlCommand cmd;
        public ADOBankRepo() {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSqlLocalDB; database=ZuciBankDB; integrated security=true";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DepositAmount(string accNo, decimal amt) {
            using (TransactionScope scope = new TransactionScope())
            {
                using (con)
                {
                    cmd.CommandText = "INSERT INTO SBTransaction VALUES(@TRDATE, @ACCNO, @AMT, @TRTYPE)";
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@TRDATE", DateTime.Now);
                    cmd.Parameters.AddWithValue("@ACCNO", accNo);
                    cmd.Parameters.AddWithValue("@AMT", amt);
                    cmd.Parameters.AddWithValue("@TRTYPE", "D");
                    con.Open();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "UPDATE SBAccount SET CurrentBalance=CurrentBalance+@AMT WHERE AccountNumber=@ACCNO";
                    //throw new Exception("Power cut");
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                scope.Complete();   // Commit the transaction
            }
        }
        public SBAccount GetAccount(string accNo) {
            cmd.CommandText = "SELECT * FROM SBAccount WHERE AccountNumber='" + accNo + "'";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows) {
                SBAccount account = new SBAccount();
                reader.Read();
                account.AccountNumber = (string)reader["AccountNumber"];
                account.CustomerName = (string)reader["CustomerName"];
                account.CustomerAddress = (string)reader["CustomerAddress"];
                account.CurrentBalance = (decimal)reader["CurrentBalance"];
                con.Close();
                return account;
            }
            else {
                con.Close();
                throw new Exception("No such A/C #");
            }
        }
        public List<SBAccount> GetAllAccounts() {
            cmd.CommandText = "SELECT * FROM SBAccount";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<SBAccount> accounts = new List<SBAccount>();
            while(reader.Read()) {
                SBAccount account = new SBAccount();
                account.AccountNumber = (string)reader["AccountNumber"];
                account.CustomerName = (string)reader["CustomerName"];
                account.CustomerAddress = (string)reader["CustomerAddress"];
                account.CurrentBalance = (decimal)reader["CurrentBalance"];
                accounts.Add(account);
            }
            con.Close();
            return accounts;
        }
        public List<SBTransaction> GetTransactions(string accNo) {
            cmd.CommandText = "SELECT * FROM SBTransaction WHERE AccountNumber = '" + accNo + "'";
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<SBTransaction> transactions = new List<SBTransaction>();
            while(reader.Read()) {
                SBTransaction transaction = new SBTransaction();
                transaction.TransactionId = (int)reader["TransactionId"];
                transaction.TransactionDate = (DateTime)reader["TransactionDate"];
                transaction.AccountNumber = (string)reader["AccountNumber"];
                transaction.Amount = (decimal)reader["Amount"];
                transaction.TransactionType = (string)reader["TransactionType"];
                transactions.Add(transaction);
            }
            con.Close();
            return transactions;
        }
        public void NewAccount(SBAccount account) {
            cmd.CommandText = "INSERT INTO SBAccount VALUES(@ACCNO, @CUSTNAME, @CUSTADDR, @CURBAL)";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@ACCNO", account.AccountNumber);
            cmd.Parameters.AddWithValue("@CUSTNAME", account.CustomerName);
            cmd.Parameters.AddWithValue("@CUSTADDR", account.CustomerAddress);
            cmd.Parameters.AddWithValue("@CURBAL", account.CurrentBalance);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void WithdrawAmount(string accNo, decimal amt) {
            SBAccount account = GetAccount(accNo);
            if (account.CurrentBalance >= amt) {
                using (TransactionScope scope = new TransactionScope()) {
                    using (con) {
                        cmd.CommandText = "INSERT INTO SBTransaction VALUES(@TRDATE, @ACCNO, @AMT, @TRTYPE)";
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@TRDATE", DateTime.Now);
                        cmd.Parameters.AddWithValue("@ACCNO", accNo);
                        cmd.Parameters.AddWithValue("@AMT", amt);
                        cmd.Parameters.AddWithValue("@TRTYPE", "W");
                        con.Open();
                        cmd.ExecuteNonQuery();
                        cmd.CommandText = "UPDATE SBAccount SET CurrentBalance=CurrentBalance-@AMT WHERE AccountNumber=@ACCNO";
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    scope.Complete();
                }
            }
            else {
                throw new Exception("Insufficient funds");
            }
        }
    }
}
