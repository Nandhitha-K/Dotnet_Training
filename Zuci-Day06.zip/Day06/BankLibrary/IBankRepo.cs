﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
    public interface IBankRepo
    {
        void NewAccount(SBAccount account);
        List<SBAccount> GetAllAccounts();
        SBAccount GetAccount(string accNo);
        void DepositAmount(string accNo, decimal amt);
        void WithdrawAmount(string accNo, decimal amt);
        List<SBTransaction> GetTransactions(string accNo);
    }
}
