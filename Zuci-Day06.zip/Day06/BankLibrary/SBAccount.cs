﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace BankLibrary
{
    public class AccNoExpressionAttribute : RegularExpressionAttribute {
        public AccNoExpressionAttribute() : base(@"\d{5}")
        {           
        }
    }
    public class BalanceValidation {
        public static ValidationResult CheckBalance(decimal curBal) {
            if (curBal < 0)
                return new ValidationResult("Balance cannot be negative");
            else
                return ValidationResult.Success;
        }
    }
    public class SBAccount {
        //[RegularExpression(@"\d{5}", ErrorMessage = "A/C # must be 5 digits")]
        [AccNoExpression(ErrorMessage = "A/C # must be 5 digits")]
        public string AccountNumber { get; set; }
        [StringLength(30, ErrorMessage = "Name must be max 30 characters")]
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        //[Range(0, 99999, ErrorMessage = "Must be 0 to 99999")]
        [CustomValidation(typeof(BalanceValidation), "CheckBalance")]
        public decimal CurrentBalance { get; set; }
    }
}
