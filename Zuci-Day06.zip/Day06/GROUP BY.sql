﻿SELECT * FROM SBAccount
SELECT * FROM SBTransaction

INSERT INTO SBAccount VALUES('100002', 'Devi', 'Mylapore', 0)
INSERT INTO SBAccount VALUES('100003', 'Suresh', 'Teynampet', 0)
INSERT INTO SBAccount VALUES('100004', 'Usha', 'Tambaram', 0)
INSERT INTO SBAccount VALUES('100005', 'Sandhiya', 'Nungambakkam', 0)

SELECT * FROM SBAccount ORDER BY CustomerName
SELECT * FROM SBAccount ORDER BY CustomerName DESC

-- Deposit Rs.5000/-
INSERT INTO SBTransaction VALUES(GETDATE(), '100002', 4000, 'D')
UPDATE SBAccount SET CurrentBalance=CurrentBalance+4000 WHERE AccountNumber='100002'

-- Withdraw Rs.2000/-
INSERT INTO SBTransaction VALUES(GETDATE(), '100002', 2000, 'W')
UPDATE SBAccount SET CurrentBalance=CurrentBalance-2000 WHERE AccountNumber='100002'

SELECT * FROM SBTransaction

-- Total deposits
SELECT SUM(AMOUNT) "Total Deposits" FROM SBTransaction WHERE TransactionType='D'

-- No. of customers
SELECT COUNT(ACCOUNTNUMBER) "No. of Customers" FROM SBAccount

-- Total deposits for each account
SELECT AccountNumber, SUM(Amount) "Total Deposits" FROM SBTransaction 
	WHERE TransactionType='D' GROUP BY AccountNumber

-- Total deposits above 5000
SELECT AccountNumber, SUM(Amount) "Total Deposits" FROM SBTransaction 
	WHERE TransactionType='D' GROUP BY AccountNumber HAVING SUM(Amount) > 5000


