﻿using System.Reflection.Metadata.Ecma335;

namespace AbstractDemo {
    abstract class Shape    // Abstract class
    {
        public abstract void Draw();    // Abstract method
        public abstract double Area { get; }   // Abstract property
        public void Erase()
        {
            Console.WriteLine("Erasing the shape");
        }
    }
    class Circle : Shape {
        double radius;
        public override double Area { 
            get { return Math.PI * radius * radius; } 
        }
        public override void Draw() {
            Console.WriteLine("Drawing a circle");
        }
        public Circle(double rad) {
            radius = rad;
        }
    }
    class Rectangle : Shape {
        double length, breadth;
        public override double Area {
            get { return length * breadth; }
        }
        public override void Draw() {
            Console.WriteLine("Drawing a rectangle");
        }
        public Rectangle(double len, double bre) {
            length = len;
            breadth = bre;
        }
    }
    sealed class MyClass { }
    class MyClass2 : MyClass { }    // Error
    internal class Program {
        static void Main(string[] args) {
            Shape shape;
            //shape = new Shape();
            shape = new Circle(6.3);
            shape.Draw();
            Console.WriteLine($"Area of circle is {shape.Area}");
            shape.Erase();
            shape = new Rectangle(7.2, 4.8);
            shape.Draw();
            Console.WriteLine($"Area of rectangle is {shape.Area}");
            shape.Erase();
        }
    }
}
