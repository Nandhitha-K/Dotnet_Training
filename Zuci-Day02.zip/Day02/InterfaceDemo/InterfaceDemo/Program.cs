﻿namespace InterfaceDemo {
    interface IShape {
        void Draw();
        double Area { get; }
    }
    interface IShape2 {
        void Paint();
    }
    class Circle : IShape, IShape2 {
        double radius;
        public double Area {
            get { return Math.PI * radius * radius;  }
        }
        public void Draw() {
            Console.WriteLine("Drawing a circle");
        }
        public void Paint() {
            Console.WriteLine("Painting the circle");
        }
        public Circle(double rad) {
            radius = rad;
        }
    }
    class Rectangle : IShape, IShape2 {
        double length, breadth;
        public double Area { 
            get { return length * breadth; } 
        }
        public void Draw() {
            Console.WriteLine("Drawing a rectangle");
        }
        public void Paint() {
            Console.WriteLine("Painting the rectangle");
        }
        public Rectangle(double len, double bre) {
            length = len; breadth = bre;
        }
    }
    internal class Program {
        static void Main(string[] args) {
            //IShape shape;
            Circle shape;
            shape = new Circle(8.3);
            shape.Draw();
            Console.WriteLine($"Area of the circle is {shape.Area}");
            shape.Paint();
            Rectangle shape2 = new Rectangle(7.4, 5.6);
            shape2.Draw();
            Console.WriteLine($"Area of the rectangle is {shape2.Area}");
            shape2.Paint();
        }
    }
}
