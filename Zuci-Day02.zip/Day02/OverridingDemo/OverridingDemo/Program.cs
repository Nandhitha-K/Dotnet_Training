﻿namespace OverridingDemo
{
    class Shape {
        public virtual void Draw()
        {
        }
    }
    class Circle : Shape {
        public override void Draw()
        {
            Console.WriteLine("Drawing a circle");
        }
    }
    class Rectangle : Shape {
        public override void Draw()
        {
            Console.WriteLine("Drawing a rectangle");
        }
    }
    internal class Program {
        static void Main(string[] args) {
            Shape shape;
            shape = new Rectangle();
            shape.Draw();
            shape = new Circle();
            shape.Draw();
        }
    }
}
