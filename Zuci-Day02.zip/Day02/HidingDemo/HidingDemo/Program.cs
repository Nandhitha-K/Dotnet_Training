﻿namespace HidingDemo
{
    class Parent {
        public void Greet() {
            Console.WriteLine("Welcome from parent");
        }
        public virtual void Wish()  // Virtual method
        {
            Console.WriteLine("Good afternoon from parent");
        }
    }
    class Child : Parent {
        public void Greet() // Hiding
        {
            Console.WriteLine("Welcome from child");
        }
        public override void Wish() // Overriding
        {
            Console.WriteLine("Good afternoon from child");
        }
    }
    internal class Program {
        static void Main(string[] args) {
            Parent obj;
            obj = new Child();
            obj.Greet();    // Compile-time polymorphism or early binding
            obj.Wish();     // Run-time polymorphism or late binding
        }
    }
}
