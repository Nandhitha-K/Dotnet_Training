﻿using System.Runtime.ConstrainedExecution;

namespace ClassDemo
{
    class Person
    {
        string name;    // Fields
        public string Name  // Property
        {
            get { return name; }    // Getter
            set { name = value; }   // Setter
        }
        private DateTime doBirth;   // propfull tab twice
        public DateTime DoBirth
        {
            get { return doBirth; }
            set { doBirth = value; }
        }
        public byte Age     // Read-only property
        {
            get { return (byte)(DateTime.Now.Year - doBirth.Year);  }
        }
        private string password;
        public string Password     // Write-only property
        {
            set { password = value; }
        }
        public void AcceptDetails() // Method
        {
            Console.Write("Enter name: ");
            name = Console.ReadLine();
            Console.Write("Enter date of birth: ");
            doBirth = Convert.ToDateTime(Console.ReadLine());
            Console.Write("Enter password: ");
            password = Console.ReadLine();
        }
        public void DisplayDetails()
        {
            Console.WriteLine($"Name: {name}, DoB: {doBirth}, Age: {Age}");
        }
        public Person()     // Default Constructor  (ctor)
        {
            name = "";
            doBirth = Convert.ToDateTime("01/01/2001");
            password = "zuci@123";
        }
        public Person(string name, DateTime dob, string pwd)    // Parameterised constructor
        {
            this.name = name;
            doBirth = dob;
            password = pwd;
        }
    }
    class Employee : Person // Inheritance
    {
        private int empId;
        public int EmpId
        {
            get { return empId; }
            set { empId = value; }
        }
        private decimal salary;
        public decimal Salary {
            get { return salary; }
            set { salary = value; }
        }
        public Employee() {
            empId = 0;
            salary = 0;
        }
        public Employee(string name, DateTime dob, string pwd, int eid, decimal sal) : base(name, dob, pwd) {
            empId = eid;
            salary = sal;
        }
        public void AcceptDetails() {
            base.AcceptDetails();
            Console.Write("Enter emp id: ");
            empId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter salary: ");
            salary = Convert.ToDecimal(Console.ReadLine());
        }
        public void DisplayDetails() {
            base.DisplayDetails();
            Console.WriteLine($"Emp Id: {empId}, Salary: {salary}");
        }
    }
    class Manager : Employee    // Multi-level inheritance
    {

    }
    internal class Program {
        static void Main(string[] args) {
            Employee emp = new Employee();
            emp.AcceptDetails();
            emp.DisplayDetails();
            Employee emp2 = new Employee("Devi", Convert.ToDateTime("04/05/2005"), "abc@123", 102, 5000);
            emp2.DisplayDetails();
            Person per;     // Declare the object
            per = new Person(); // Instantiate the object
            //per.AcceptDetails();
            per.DisplayDetails();
            Person per2 = new Person("Suresh", Convert.ToDateTime("05/04/2003"), "secret");
            per2.DisplayDetails();
            /*Console.Write("Enter name: ");
            per.Name = Console.ReadLine();  // setter is called
            Console.WriteLine(per.Name);    // getter is called
            Console.Write("Enter date of birth: ");
            per.DoBirth = Convert.ToDateTime(Console.ReadLine());
            Console.Write("Enter password: ");
            per.Password = Console.ReadLine();*/
            //per.Age = 18;     // Error
            //Console.WriteLine(per.Age);
            //Console.WriteLine(per.Password);  // Error
        }
    }
}
