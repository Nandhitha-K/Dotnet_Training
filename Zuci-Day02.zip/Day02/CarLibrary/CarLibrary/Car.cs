﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    public class Car
    {
        private string make;
        public string Make
        {
            get { return make; }
            set { make = value; }
        }
        private Color color;
        public Color Color
        {
            get { return color; }
            set { color = value; }
        }
        private Engine engine;
        public Engine Engine
        {
            get { return engine; }
            set { engine = value; }
        }
        public Wheel[] wheels = new Wheel[4];
    }
}
