﻿namespace CarLibrary
{
    public class Engine
    {
        private string engineNo;
        public string EngineNo
        {
            get { return engineNo; }
            set { engineNo = value; }
        }
        private string mdoel;
        public string Model
        {
            get { return mdoel; }
            set { mdoel = value; }
        }
    }
}
