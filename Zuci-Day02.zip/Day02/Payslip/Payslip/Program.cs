﻿using System.Diagnostics;

namespace Payslip
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int empId;
            string empName;
            char grade;
            decimal salary, hra, da, pf, gross, net;
            Console.Write("Enter emp id: ");
            empId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter name: ");
            empName = Console.ReadLine();
            Console.Write("Enter grade: ");
            grade = Convert.ToChar(Console.ReadLine());
            Console.Write("Enter salary: ");
            salary = Convert.ToDecimal(Console.ReadLine());
            decimal hraper, daper;
            hraper = 0; daper = 0;
            switch(grade)
            {
                case 'A': hraper = 0.20M; daper = 0.30M; break;
                case 'B': hraper = 0.15M; daper = 0.20M; break;
                case 'C': hraper = 0.10M; daper = 0.15M; break;
                case 'D': hraper = 0.05M; daper = 0.10M; break;
            }
            hra = salary * hraper;
            da = salary * daper;
            pf = salary * 0.12M;
            gross = salary + hra + da;
            net = gross - pf;
            Console.WriteLine($"HRA = {hra}, DA = {da}, PF = {pf}");
            Console.WriteLine($"Gross pay = {gross}, Net pay = {net}");
        }
    }
}
