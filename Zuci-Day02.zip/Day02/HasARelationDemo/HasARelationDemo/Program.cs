﻿using System.Drawing;
using CarLibrary;
namespace HasARelationDemo {
    internal class Program {
        static void Main(string[] args) {
            Car car = new Car();
            Console.Write("Enter the car make: ");
            car.Make = Console.ReadLine();
            Console.Write("Enter the car color: ");
            string color =  Console.ReadLine();
            car.Color = Color.FromName(color);
            Console.Write("Enter the engine number: ");
            car.Engine = new Engine();
            car.Engine.EngineNo = Console.ReadLine();
            Console.Write("Enter the engine model: ");
            car.Engine.Model = Console.ReadLine();
            for (int i = 0; i < 4; i++) {
                car.wheels[i] = new Wheel();
            }
            car.wheels[0].Name = "FrontLeft";
            car.wheels[1].Name = "FrontRight";
            car.wheels[2].Name = "RearLeft";
            car.wheels[3].Name = "RearRight";
            Console.WriteLine($"Car make: {car.Make}, Color: {car.Color.Name}, Engine no.: {car.Engine.EngineNo}, Model: {car.Engine.Model}");
            Console.WriteLine("Wheels in the car...");
            foreach (Wheel wheel in car.wheels) {
                Console.WriteLine(wheel.Name);
            }
        }
    }
}
