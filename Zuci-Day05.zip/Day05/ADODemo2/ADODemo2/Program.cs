﻿using System.Data.SqlClient;

namespace ADODemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            Console.Write("Enter emp id: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            cmd.CommandText = "SELECT EMPNAME FROM EMPLOYEE WHERE EMPID = " + eid;
            con.Open();
            // To execute a SELECT statement returning a single value
            string ename = (string)cmd.ExecuteScalar();
            con.Close();
            if (string.IsNullOrEmpty(ename))
                Console.WriteLine("No such emp id");
            else
                Console.WriteLine($"Name: {ename}");
        }
    }
}
