﻿CREATE DATABASE ZuciDB

USE ZuciDB

CREATE TABLE Employee (
EmpId INT PRIMARY KEY,
EmpName VARCHAR(30) NOT NULL,
Salary MONEY)

INSERT INTO Employee VALUES(101, 'Ramesh', 5000)

SELECT * FROM Employee

INSERT INTO Employee VALUES(102, null, 6000)	-- error
INSERT INTO Employee VALUES(101, 'Devi', 6000)	-- error
INSERT INTO Employee(EmpId, EmpName) VALUES(102, 'Devi')
INSERT INTO Employee(EmpName, Salary) VALUES('Suresh',5500) -- error

UPDATE Employee SET Salary=5500 WHERE EmpId=101
UPDATE Employee SET Salary=6000 WHERE EmpName='Devi'
UPDATE Employee SET Salary=Salary+1000

DELETE FROM Employee WHERE EmpId=101


