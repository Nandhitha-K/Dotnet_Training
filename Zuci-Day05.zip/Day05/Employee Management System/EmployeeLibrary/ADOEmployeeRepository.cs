﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace EmployeeLibrary {
    public class ADOEmployeeRepository : IEmployeeRepository {
        SqlConnection con;
        SqlCommand cmd;
        public ADOEmployeeRepository() {
            con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciDB; integrated security=true";
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
        public void DeleteEmployee(int eid) {
            cmd.CommandText = "DELETE FROM EMPLOYEE WHERE EMPID = " + eid;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public List<Employee> GetAllEmployees() {
            cmd.CommandText = "SELECT * FROM EMPLOYEE";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            List<Employee> employees = new List<Employee>();
            while(drdr.Read()) {
                Employee employee = new Employee();
                employee.EmpId = (int)drdr["EmpId"];
                employee.EmpName = (string)drdr["EmpName"];
                employee.Salary = (decimal)drdr["Salary"];
                employees.Add(employee);
            }
            con.Close();
            return employees;
        }
        public Employee GetEmployeeById(int eid) {
            cmd.CommandText = "SELECT * FROM EMPLOYEE WHERE EMPID = " + eid;
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            if (drdr.HasRows) {
                drdr.Read();
                Employee employee = new Employee();
                employee.EmpId = (int)drdr["EmpId"];
                employee.EmpName = (string)drdr["EmpName"];
                employee.Salary = (decimal)drdr["Salary"];
                con.Close();
                return employee;
            }
            else {
                con.Close();
                throw new EmpException("No such emp id");
            }
        }
        public void InsertEmployee(Employee employee) {
            cmd.CommandText = "INSERT INTO EMPLOYEE VALUES(@EID, @ENAME, @SAL)";
            cmd.Parameters.AddWithValue("@EID", employee.EmpId);
            cmd.Parameters.AddWithValue("@ENAME", employee.EmpName);
            cmd.Parameters.AddWithValue("@SAL", employee.Salary);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void UpdateEmployee(int eid, Employee employee) {
            cmd.CommandText = "UPDATE EMPLOYEE SET EMPNAME=@ENAME, SALARY=@SAL WHERE EMPID = @EID";
            cmd.Parameters.AddWithValue("@EID", employee.EmpId);
            cmd.Parameters.AddWithValue("@ENAME", employee.EmpName);
            cmd.Parameters.AddWithValue("@SAL", employee.Salary);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
