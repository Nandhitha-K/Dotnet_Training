﻿using System.Data.SqlClient;
namespace ADODemo5
{
    internal class Program
    {
        static void Main(string[] args) {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            Console.Write("Enter emp id: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            cmd.CommandText = "SELECT EMPNAME, SALARY FROM EMPLOYEE WHERE EMPID = " + eid;
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            try  {
                drdr.Read();
                string ename = (string)drdr["EMPNAME"];
                decimal sal = (decimal)drdr["SALARY"];
                Console.WriteLine($"Name: {ename}, Salary: {sal}");
                Console.Write("Enter new salary: ");
                sal = Convert.ToDecimal(Console.ReadLine());
                cmd.CommandText = "UPDATE EMPLOYEE SET SALARY=@SAL WHERE EMPID=@EID";
                cmd.Parameters.AddWithValue("@SAL", sal);
                cmd.Parameters.AddWithValue("@EID", eid);
                drdr.Close();
                cmd.ExecuteNonQuery();
                Console.WriteLine("Salary updated.");
            }
            catch {
                Console.WriteLine("No such emp id");
            }
            con.Close();
        }
    }
}
