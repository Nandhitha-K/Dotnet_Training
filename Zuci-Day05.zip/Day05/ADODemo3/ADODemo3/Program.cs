﻿using System.Data.SqlClient;

namespace ADODemo3
{
    internal class Program
    {
        static void Main(string[] args) {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            Console.Write("Enter emp id: ");
            int eid = Convert.ToInt32(Console.ReadLine());
            cmd.CommandText = "SELECT EMPNAME, SALARY FROM EMPLOYEE WHERE EMPID = " + eid;
            con.Open();
            // To execute SELECT statement retuning multiple rows and/or columns
            SqlDataReader drdr = cmd.ExecuteReader();
            try {
                drdr.Read();
                string ename = (string)drdr["EMPNAME"];
                decimal sal = (decimal)drdr["SALARY"];
                Console.WriteLine($"Name: {ename}, Salary: {sal}");
            }
            catch {
                Console.WriteLine("No such emp id");
            }
            con.Close();
        }
    }
}
