﻿using System.Data.SqlClient;

namespace ADODemo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciDB; integrated security=true";
            try
            {
                con.Open();
                Console.WriteLine("Connected to database successfully");
                Console.Write("Enter emp id: ");
                int eid = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter name: ");
                string ename = Console.ReadLine();
                Console.Write("Enter salary: ");
                decimal sal = Convert.ToDecimal(Console.ReadLine());
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                //cmd.CommandText = "INSERT INTO Employee VALUES(" + eid + ",'" + ename + "'," + sal + ")";
                cmd.ExecuteNonQuery();  // To execute DDL and DML statements
                Console.WriteLine("New employee added.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
