﻿namespace LambdaDemo {
    class Employee {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public decimal Salary { get; set; }
    }
    internal class Program {
        static void Main(string[] args) {
            Employee emp = new Employee() { EmpId = 101, EmpName = "Ramesh", Salary = 5000 };
            Employee emp2 = new Employee() { EmpId = 102, EmpName = "Devi", Salary = 6000 };
            List<Employee> employees = new List<Employee>() {
                emp,
                emp2,
                new Employee() { EmpId = 103, EmpName = "Suresh", Salary = 5500 },
                new Employee() { EmpId = 104, EmpName = "Usha", Salary = 7000 }
            };
            // Find the emps getting 6000 or above
            /*List<Employee> emps = new List<Employee>();
            foreach (Employee employee in employees) {
                if (employee.Salary >= 6000)
                    emps.Add(employee);
            }*/
            // Lambda
            //var emps = employees.Where(e => e.Salary >= 6000);
            // LINQ (Language Integrated Query)
            var emps = from e in employees where e.Salary >= 6000 select e;
            Console.WriteLine("Emps getting 6000 or above...");
            foreach (Employee employee in emps) {
                Console.WriteLine($"Emp Id: {employee.EmpId}, Name: {employee.EmpName}, Salary: {employee.Salary}");
            }
            // The emp ids of the emps getting 6000 or above
            //var eids = employees.Where(e => e.Salary >= 6000).Select(e => e.EmpId);
            var eids = from e in employees where e.Salary >= 6000 select e.EmpId;
            Console.WriteLine("Emp ids of emps getting 6000 or above...");
            foreach (int eid in eids) {
                Console.WriteLine(eid);
            }
            // The ids and names of the emps getting 6000 or above
            //var eidsnames = employees.Where(e => e.Salary >= 6000).Select(e => new { e.EmpId, e.EmpName });
            var eidsnames = from e in employees where e.Salary >= 6000 select new { e.EmpId, e.EmpName };
            Console.WriteLine("Emp ids and names of emps getting 6000 or above...");
            foreach (var x in eidsnames) {
                Console.WriteLine($"Emp Id: {x.EmpId}, Name: {x.EmpName}");
            }
            Console.Write("Enter an emp id: ");
            int empid = Convert.ToInt32(Console.ReadLine());
            try {
                //Employee empl = employees.Single(e => e.EmpId == empid);
                Employee empl = (from e in employees where e.EmpId == empid select e).First();
                Console.WriteLine($"Name: {empl.EmpName}, Salary: {empl.Salary}");
            }
            catch {
                Console.WriteLine("No such emp id");
            }
        }
    }
}
