﻿CREATE DATABASE ZuciBankDB

USE ZuciBankDB

CREATE TABLE SBAccount (
AccountNumber CHAR(6) PRIMARY KEY,
CustomerName VARCHAR(30) NOT NULL,
CustomerAddress VARCHAR(50),
CurrentBalance MONEY)

CREATE TABLE SBTransaction (
TransactionId INT PRIMARY KEY IDENTITY,
TransactionDate DATETIME,
AccountNumber CHAR(6) REFERENCES SBAccount(AccountNumber),
Amount MONEY,
TransactionType CHAR(1) CHECK (TransactionType IN ('D','W')))

INSERT INTO SBAccount VALUES('100001', 'Ramesh', 'Thoraipakkam', 0)

-- Deposit Rs.5000/-
INSERT INTO SBTransaction VALUES(GETDATE(), '100001', 5000, 'D')
UPDATE SBAccount SET CurrentBalance=CurrentBalance+5000 WHERE AccountNumber='100001'

SELECT * FROM SBAccount
SELECT * FROM SBTransaction

-- Withdraw Rs.3000/-
INSERT INTO SBTransaction VALUES(GETDATE(), '100001', 3000, 'W')
UPDATE SBAccount SET CurrentBalance=CurrentBalance-3000 WHERE AccountNumber='100001'

-- Referential Integrity
INSERT INTO SBTransaction VALUES(GETDATE(), '100002', 3000, 'W')	-- error
DELETE FROM SBAccount WHERE AccountNumber='100001'	-- error
UPDATE SBAccount SET AccountNumber='100009' WHERE AccountNumber='100001'	-- error



