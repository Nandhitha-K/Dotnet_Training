﻿using System.Data.SqlClient;

namespace ADODemo4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"data source=(localdb)\MSSQLLocalDB; database=ZuciDB; integrated security=true";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            cmd.CommandText = "SELECT * FROM EMPLOYEE";
            con.Open();
            SqlDataReader drdr = cmd.ExecuteReader();
            while(drdr.Read())
            {
                int eid = (int)drdr["EmpId"];
                string ename = (string)drdr["EmpName"];
                decimal sal = (decimal)drdr["Salary"];
                Console.WriteLine($"Emp Id: {eid}, Name: {ename}, Salary: {sal}");
            }
            con.Close();
        }
    }
}
