﻿namespace ExceptionDemo
{
    internal class Program
    {
        static void Main(string[] args) {
            try {
                Console.Write("Enter first number: ");
                int num1 = Convert.ToInt32(Console.ReadLine());
                if (num1 < 0)
                    throw new NegativeNumberException("First number cannot be negative");
                Console.Write("Enter second number: ");
                int num2 = Convert.ToInt32(Console.ReadLine());
                if (num2 < 0)
                    throw new NegativeNumberException("Second number cannot be negative");
                if (num2 == 0)
                    throw new DivideByZeroException("Second number cannot be zero");
                int result = num1 / num2;
                Console.WriteLine($"Result = {result}");
            }
            catch(NegativeNumberException ex) {
                Console.WriteLine(ex.Message);
                return;
            }
            catch(DivideByZeroException ex) {
                Console.WriteLine(ex.Message);
                //Console.WriteLine("Second number cannot be zero");
            }
            catch(FormatException) {
                Console.WriteLine("Please enter only numbers");
            }
            catch(Exception ex) {
                Console.WriteLine(ex.Message);
            }
            finally {
                Console.WriteLine("This is always executed");
            }
        }
    }
}
