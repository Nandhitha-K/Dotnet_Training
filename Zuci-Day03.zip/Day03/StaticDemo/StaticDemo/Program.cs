﻿namespace StaticDemo
{
    class Employee {
        private int empId;  // Instance field
        public int EmpId {
            get { return empId; }
            set { empId = value; }
        }
        static int empCount; // Static field
        public Employee() {
            empCount++;
        }
        public static int GetEmpCount() {   // Static method
            //empId = 101;  // Error
            return empCount;
        }
        static Employee() {     // Static constructor
            empCount = 100;
        }
    }
    internal class Program {
        static void Main(string[] args) {
            //Console.WriteLine($"No. of emps = {Employee.empCount}");
            Console.WriteLine($"No. of emps = {Employee.GetEmpCount()}");
            Employee emp1, emp2;
            emp1 = new Employee();
            //Console.WriteLine($"No. of emps = {Employee.empCount}");
            Console.WriteLine($"No. of emps = {Employee.GetEmpCount()}");
            emp2 = new Employee();
            //Console.WriteLine($"No. of emps = {Employee.empCount}");
            Console.WriteLine($"No. of emps = {Employee.GetEmpCount()}");
        }
    }
}
