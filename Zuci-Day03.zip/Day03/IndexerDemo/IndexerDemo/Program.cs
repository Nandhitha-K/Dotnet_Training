﻿using System.Runtime.InteropServices;

namespace IndexerDemo
{
    class Student {
        private int rollNo;
        public int RollNo {
            get { return rollNo; }
            set { rollNo = value; }
        }
        private string name;
        public string Name {
            get { return name; }
            set { name = value; }
        }
        private int[] marks = new int[5];
        public int this[int i]      // Indexer
        {
            get { return marks[i]; }
            set { marks[i] = value; }
        }
        private string[] skills = new string[3];    // Indexer not possible
        private int[,] matrix = new int[4, 3];  
        public int this[int r, int c]   // Indexer overloading
        {
            get { return matrix[r, c]; }
            set { matrix[r, c] = value; }
        }
    }
    internal class Program {
        static void Main(string[] args) {
            Student stud = new Student();
            Console.Write("Enter roll no.: ");
            stud.RollNo = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter name: ");
            stud.Name = Console.ReadLine();
            for (int i = 0; i < 5; i++) {
                Console.Write($"Enter marks in subject #{i+1}: ");
                stud[i] = Convert.ToInt32(Console.ReadLine());
            }
        }
    }
}
