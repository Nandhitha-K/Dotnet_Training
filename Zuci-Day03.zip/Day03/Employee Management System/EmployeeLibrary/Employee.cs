﻿namespace EmployeeLibrary
{
    public class Employee
    {
		private int empId;
		public int EmpId
		{
			get { return empId; }
			set { empId = value; }
		}
		private string empName;
		public string EmpName
		{
			get { return empName; }
			set { empName = value; }
		}
		private decimal salary;
		public decimal Salary
		{
			get { return salary; }
			set { salary = value; }
		}
	}
}
