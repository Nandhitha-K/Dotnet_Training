﻿using MyButtonLibrary;

namespace EventDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyButton btn1 = new MyButton();
            btn1.Click += Btn1_Click;   // Attach an event handler
            btn1.SimulateClick("Hi");
            MyButton btn2 = new MyButton();
            btn2.Click += Btn2_Click;
            btn2.SimulateClick("Hello");
        }
        // Event Handlers
        private static void Btn2_Click(string s)
        {
            Console.WriteLine($"Btn2 was clicked with the message {s}");
        }
        private static void Btn1_Click(string s)
        {
            Console.WriteLine($"Btn1 was pressed with the message {s}");
        }
    }
}
