﻿using CollegeLibrary;

namespace CollegeApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student stud1 = new Student();


        }
    }
}
