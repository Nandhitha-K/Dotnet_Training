﻿namespace CollegeLibrary
{
    public class Person
    {

    }
}
