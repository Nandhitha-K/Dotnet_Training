﻿namespace DelegateDemo {
    class Arithmetic {
        public int Add(int x, int y) {
            return x + y;
        }
        public int Sub(int x, int y) {
            return x - y;
        }
        public int Mul(int x, int y) {
            return x * y;
        }
        public int Div(int x, int y) {
            return x / y;
        }
    }
    delegate int MyDele(int x, int y);  // Declare the delegate
    internal class Program {
        static void Main(string[] args) {
            Arithmetic arith = new Arithmetic();
            int a, b, res;
            a = 4;  b = 5;
            //int res = arith.Add(a, b);
            MyDele deleObj;     // Declare the delegate object
            deleObj = new MyDele(arith.Add);    // Point to a method
            res = deleObj(a, b);    // Invoke the method indirectly
            deleObj = new MyDele(arith.Mul);    // Point to a different method
            res = deleObj(a, b);
        }
    }
}
