﻿using System.Collections;
using System.Security;
namespace CollectionsDemo {
    internal class Program {
        static void Main(string[] args) {
            ArrayList fruits = new ArrayList();
            fruits.Add("Apple");
            fruits.Add("Mango");
            fruits.Add("Grape");
            fruits.Add("Banana");
            fruits.Add("Strawberry");
            int pos = fruits.IndexOf("Grape");
            fruits.RemoveRange(pos,2);
            Console.WriteLine("List of fruits...");
            for (int i = 0; i < fruits.Count; i++) {
                Console.WriteLine(fruits[i]);
            }
            // OR
            foreach (string fruit in fruits) {
                Console.WriteLine(fruit);
            }

            Stack books = new Stack();  // Last In First Out (LIFO)
            books.Push("Programming in C");
            books.Push("C++ Programming");
            books.Push("Learn Java in 21 Days");
            books.Push("C# Complete Reference");
            Console.WriteLine("Stacks of books...");
            while (books.Count != 0) {
                Console.WriteLine(books.Pop());
            }

            Queue documents = new Queue();  // First In First Out (FIFO)
            documents.Enqueue("Doc1");
            documents.Enqueue("Doc2");
            documents.Enqueue("Doc3");
            documents.Enqueue("Doc4");
            Console.WriteLine("Documents in the printer queue...");
            while (documents.Count != 0) {
                Console.WriteLine(documents.Dequeue());
            }

            Hashtable currencies = new Hashtable();
            currencies.Add('$', "USD");
            currencies.Add('E', "EUR");
            currencies.Add('R', "INR");
            currencies.Add('Y', "YEN");
            foreach (char key in currencies.Keys) {
                Console.WriteLine($"Currency for the symbol {key} is {currencies[key]}");
            }
        }
    }
}
