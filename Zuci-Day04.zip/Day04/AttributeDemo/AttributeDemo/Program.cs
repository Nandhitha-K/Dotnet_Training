﻿#define DISPLAY

using System.Diagnostics;

namespace AttributeDemo
{
    internal class Program
    {
        [Conditional("DISPLAY")]
        static void PrintData(object x)
        {
            Console.WriteLine(x);
        }
        static void Main(string[] args)
        {
            int num = 5;
            PrintData(num);
            string name = "Zuci";
            PrintData(name);
            DateTime today = DateTime.Now;
            PrintData(today);
        }
    }
}
