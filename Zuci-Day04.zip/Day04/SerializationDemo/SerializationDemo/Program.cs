﻿using EmployeeLibrary;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SerializationDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.EmpId = 101;
            emp.EmpName = "Ramesh";
            emp.Salary = 5000;
            FileStream fs = new FileStream(@"E:\Zuci-DotNet\Day04\Emp.dat", FileMode.Create);
            BinaryFormatter binfor = new BinaryFormatter();
            binfor.Serialize(fs, emp);
            fs.Close();
        }
    }
}
