﻿using System.IO;

namespace IODemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream(@"E:\Zuci-DotNet\Day04\Sample.txt", FileMode.Create);
            byte[] arr = new byte[26];
            for (int i = 0; i < 26; i++)
            {
                arr[i] = (byte)(i + 65);
            }
            fs.Write(arr, 0, 26);
            fs.Close();
        }
    }
}
