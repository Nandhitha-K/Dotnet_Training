﻿using System.IO;

namespace StreamWriterDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StreamWriter sw = new StreamWriter(@"E:\Zuci-DotNet\Day04\Example.txt");
            sw.WriteLine("This is the first line.");
            sw.Write("This is the ");
            sw.Write("second line");
            sw.WriteLine();
            sw.WriteLine(DateTime.Now);
            sw.Close();

            StreamReader sr = new StreamReader(@"E:\Zuci-DotNet\Day04\Example.txt");
            /*string str = sr.ReadLine();
            Console.WriteLine(str);
            str = sr.ReadToEnd();
            Console.WriteLine(str);*/
            while(!sr.EndOfStream)
            {
                string str = sr.ReadLine();
                Console.WriteLine(str);
            }
            sr.Close();
        }
    }
}
