﻿namespace GenericCollectionsDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> fruits = new List<string>();
            fruits.Add("Apple");
            //fruits.Add(5);

            Stack<string> books = new Stack<string>();
            books.Push("Programming in C");

            Queue<string> documents = new Queue<string>();
            documents.Enqueue("Doc1");

            Dictionary<char, string> currencies = new Dictionary<char, string>();
            currencies.Add('$', "USD");
        }
    }
}
