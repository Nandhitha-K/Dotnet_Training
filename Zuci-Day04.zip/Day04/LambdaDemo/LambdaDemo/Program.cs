﻿namespace LambdaDemo {
    class Employee {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public decimal Salary { get; set; }
    }
    internal class Program {
        static void Main(string[] args) {
            Employee emp = new Employee() { EmpId = 101, EmpName = "Ramesh", Salary = 5000 };
            Employee emp2 = new Employee() { EmpId = 102, EmpName = "Devi", Salary = 6000 };
            List<Employee> employees = new List<Employee>() {
                emp,
                emp2,
                new Employee() { EmpId = 103, EmpName = "Suresh", Salary = 5500 },
                new Employee() { EmpId = 104, EmpName = "Usha", Salary = 7000 }
            };
            // Find the emps getting 6000 or above
            List<Employee> emps = new List<Employee>();
            foreach (Employee employee in employees) {
                if (employee.Salary >= 6000)
                    emps.Add(employee);
            }
            Console.WriteLine("Emps getting 6000 or above...");
            foreach (Employee employee in emps) {
                Console.WriteLine($"Emp Id: {employee.EmpId}, Name: {employee.EmpName}, Salary: {employee.Salary}");
            }
        }
    }
}
