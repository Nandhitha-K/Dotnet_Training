﻿namespace MyButtonLibrary
{
    public delegate void MyDele(string s);

    public class MyButton
    {
        public event MyDele Click;  // Declare the event
        public void SimulateClick(string msg)
        {
            Click(msg);         // Fire the event
        }
    }
}
