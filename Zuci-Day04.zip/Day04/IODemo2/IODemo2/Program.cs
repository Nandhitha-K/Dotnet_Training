﻿using System.IO;

namespace IODemo2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream(@"E:\Zuci-DotNet\Day04\Sample.txt", FileMode.Open);
            byte[] arr = new byte[26];
            fs.Read(arr, 0, 26);
            foreach (byte b in arr)
            {
                Console.Write((char)b);
            }
            fs.Close();
        }
    }
}
