﻿using System.Reflection;

namespace CSharp3Demo
{
    class Employee {
       /*private int empId;
        public int EmpId {
            get { return empId; }
            set { empId = value; }
        }*/
        public int EmpId { get; set; }   // Automatic property
        public string EmpName { get; set; }
        public decimal Salary { get; set; }
    }
    internal class Program {
        static void Main(string[] args) {
            var num = 5;    // Implicitly typed local variable
            //num = "Apple";    // error
            //var name;     // error
            // Object initializer
            Employee emp = new Employee() { EmpId = 101, EmpName = "Ramesh", Salary = 5000 };
            Employee emp2 = new Employee() { EmpId = 102, EmpName = "Devi", Salary = 6000 };
            // Collection initializer
            List<Employee> employees = new List<Employee>() { 
                emp, 
                emp2, 
                new Employee() { EmpId = 103, EmpName = "Suresh", Salary = 5500 }, 
                new Employee() { EmpId = 104, EmpName = "Usha", Salary = 7000 } 
            };
            // Anonymous type
            var cust = new { CustId = 501, CustName = "Wipro", CustAddr = "Bengaluru" };
            Console.WriteLine($"Customer Id: {cust.CustId}, Name: {cust.CustName}, Address: {cust.CustAddr}");
            //cust.CustAddr = "Mysore";   // Properties in Anonymous type are read-only



        }
    }
}
