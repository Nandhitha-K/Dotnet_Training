﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class EmployeeRepository : IEmployeeRepository {
        static ArrayList employees = new ArrayList();
        public void DeleteEmployee(int eid) {
            Employee emp2del = GetEmployeeById(eid);
            employees.Remove(emp2del);
        }
        public ArrayList GetAllEmployees() {
            return employees;
        }
        public Employee GetEmployeeById(int eid) {
            Employee emp = null;
            foreach (Employee employee in employees) {
                if (employee.EmpId == eid) {
                    emp = employee;
                    break;
                }
            }
            if (emp == null)
                throw new EmpException("No such emp id");
            else
                return emp;
        }
        public void InsertEmployee(Employee employee) {
            employees.Add(employee);
        }
        public void UpdateEmployee(int eid, Employee employee) {
            Employee emp2edit = GetEmployeeById(eid);
            emp2edit.EmpName = employee.EmpName;
            emp2edit.Salary = employee.Salary;
        }
    }
}
