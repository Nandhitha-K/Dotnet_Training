﻿namespace PartialMethodDemo
{
    partial class Sample
    {
        partial void Method2();
        public void Method1()
        {
            Method2();
        }
    }
    partial class Sample
    {
        partial void Method2()
        {

        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Sample obj = new Sample();
            obj.Method1();
        }
    }
}
