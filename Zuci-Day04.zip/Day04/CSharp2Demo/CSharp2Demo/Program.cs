﻿
namespace CSharp2Demo {
    static class Sample // Static class
    {
        static int num; // All members must be static
        public static void Display() {
            Console.WriteLine(num);
        }
    }
    partial class Example {
        public void Method1() { }
    }
    partial class Example {
        public void Method2() { }
    }
    class Employee {
        private int empId;
        public int EmpId {      // Property with multiple access modifiers
            get { return empId; }
            protected set { empId = value; }
        }
    }
    class Manager : Employee {
        public Manager() {
            EmpId = 101;
        }
    }
    internal class Program {
        static void Main(string[] args) {
            //Sample obj;   Error
            Sample.Display();
            Example obj = new Example();
            obj.Method1();  
            obj.Method2();
            obj = null;
            int? num = null;    // Nullable type
            Employee emp = new Employee();
            //emp.EmpId = 101;  // Error
            Console.WriteLine(emp.EmpId);
        }
    }
}
