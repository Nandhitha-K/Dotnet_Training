﻿namespace ExtensionMethodsDemo
{
    class Sample
    {
        public void Method1() { }
    }
    /*class Example : Sample
    {
        public void Method2() { }
    }*/
    static class Xyz {
        public static void Method2(this Sample s, int n) { }   // Extension method
        public static bool IsValidEmail(this string s)
        {
            if (s.Contains('@'))
                return true;
            else
                return false;
        }
    }
    internal class Program {
        static void Main(string[] args) {
            Sample obj = new Sample();
            //Example obj = new Example();
            obj.Method1();
            obj.Method2(5);
            string email = "abc@zuci.com";
            if (email.IsValidEmail())
                Console.WriteLine("Valid email");
            else
                Console.WriteLine("Invalid email");
        }
    }
}
