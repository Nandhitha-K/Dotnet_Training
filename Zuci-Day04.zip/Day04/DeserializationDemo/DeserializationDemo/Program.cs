﻿using EmployeeLibrary;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DeserializationDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream(@"E:\Zuci-DotNet\Day04\Emp.dat", FileMode.Open);
            BinaryFormatter binfor = new BinaryFormatter();
            Employee emp = binfor.Deserialize(fs) as Employee;
            fs.Close();
            Console.WriteLine($"Emp Id: {emp.EmpId}, Name: {emp.EmpName}, Salary: {emp.Salary}");
        }
    }
}
