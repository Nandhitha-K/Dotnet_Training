﻿using System.Runtime.InteropServices.ObjectiveC;

namespace GenericDemo
{
    internal class Program
    {
        /*static void Swap(ref int x, ref int y)
        {
            int t = x;
            x = y;
            y = t;
        }
        static void Swap(ref double x, ref double y)
        {
            double t = x;
            x = y;
            y = t;
        }*/
        /*static void Swap(ref object x, ref object y)
        {
            object t = x;
            x = y;
            y = t;
        }*/
        static void Swap<T>(ref T x, ref T y)   // Generic method
        {
            T t = x;
            x = y;
            y = t;
        }
        static void Print<T1,T2>(T1 num, T2 str) {
        }
        static void Main(string[] args) {
            int a, b;
            a = 4;  b = 5;
            Swap<int>(ref a, ref b);
            Console.WriteLine($"a={a}, b={b}");
            double c, d;
            c = 3.14;   d = 7.23;
            Swap(ref c, ref d);
            char e, f;
            e = '$';    f = '#';
            Swap(ref e, ref f);
            MyClass<int> obj = new MyClass<int>();
            MyClass<string> obj2 = new MyClass<string>();
        }
    }
    class MyClass<T>    // Generic class
    {
        T num;
    }
}
