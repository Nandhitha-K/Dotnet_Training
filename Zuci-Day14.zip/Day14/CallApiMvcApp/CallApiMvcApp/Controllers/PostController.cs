﻿using CallApiMvcApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CallApiMvcApp.Controllers
{
    public class PostController : Controller {
        static HttpClient svc = new HttpClient { BaseAddress = new Uri("https://jsonplaceholder.typicode.com/posts/") };
        public async Task<ActionResult> Index() {
            List<Post> posts = await svc.GetFromJsonAsync<List<Post>>("");
            return View(posts);
        }
        public async Task<ActionResult> Details(int id) {
            Post post = await svc.GetFromJsonAsync<Post>("" + id);
            return View(post);
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Post post) {
            try {
                await svc.PostAsJsonAsync<Post>("", post);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public async Task<ActionResult> Edit(int id) {
            Post post = await svc.GetFromJsonAsync<Post>("" + id);
            return View(post);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, Post post) {
            try {
                await svc.PutAsJsonAsync<Post>("" + id, post);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public async Task<ActionResult> Delete(int id) {
            Post post = await svc.GetFromJsonAsync<Post>("" + id);
            return View(post);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id, IFormCollection collection) {
            try {
                await svc.DeleteAsync("" + id);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
    }
}
