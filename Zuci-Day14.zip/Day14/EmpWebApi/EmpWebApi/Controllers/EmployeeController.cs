﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EmployeeLibrary;
namespace EmpWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase {
        IEmployeeRepository repo;
        public EmployeeController(IEmployeeRepository empRepo) {
            repo = empRepo;
        }
        [HttpGet]
        public ActionResult GetAll() {
            List<Employee> employees = repo.GetAllEmployees();
            return Ok(employees);
        }
        [HttpGet("{eid}")]
        public ActionResult GetOne(int eid) {
            try {
                Employee employee = repo.GetEmployeeById(eid);
                return Ok(employee);
            }
            catch (EmpException ex) {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public ActionResult Insert(Employee employee) {
            try {
                repo.InsertEmployee(employee);
                return Created($"api/Employee/{employee.EmpId}", employee);
            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("{eid}")]
        public ActionResult Update(int eid, Employee employee) {
            try {
                repo.UpdateEmployee(eid, employee);
                return Ok(employee);
            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{eid}")]
        public ActionResult Delete(int eid) {
            try {
                repo.DeleteEmployee(eid);
                return Ok();
            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }
    }
}
