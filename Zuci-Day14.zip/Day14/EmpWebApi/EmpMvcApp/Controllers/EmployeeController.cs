﻿using EmployeeLibrary;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewComponents;

namespace EmpMvcApp.Controllers
{
    public class EmployeeController : Controller {
        static HttpClient svc = new HttpClient { BaseAddress = new Uri("http://localhost:5084/api/Employee/") };
        public async Task<ActionResult> Index() {
            List<Employee> employees = await svc.GetFromJsonAsync<List<Employee>>("");
            return View(employees);
        }
        public async Task<ActionResult> Details(int id) {
            Employee employee = await svc.GetFromJsonAsync<Employee>("" + id);
            return View(employee);
        }
        public ActionResult Create() {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Employee employee) {
            try {
                await svc.PostAsJsonAsync<Employee>("", employee);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public async Task<ActionResult> Edit(int id) {
            Employee employee = await svc.GetFromJsonAsync<Employee>("" + id);
            return View(employee);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, Employee employee) {
            try {
                await svc.PutAsJsonAsync<Employee>("" + id, employee);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public async Task<ActionResult> Delete(int id) {
            Employee employee = await svc.GetFromJsonAsync<Employee>("" + id);
            return View(employee);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id, IFormCollection collection) {
            try {
                await svc.DeleteAsync("" + id);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
    }
}
