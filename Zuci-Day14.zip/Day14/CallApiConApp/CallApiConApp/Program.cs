﻿using System.Net.Http.Json;

namespace CallApiConApp
{
    internal class Program {
        static HttpClient svc = new HttpClient() { BaseAddress = new Uri("https://jsonplaceholder.typicode.com/posts/") };
        static async Task Main(string[] args) {
            while(true) {
                Console.WriteLine("-----------------");
                Console.WriteLine("- - -M E N U- - -");
                Console.WriteLine("-----------------");
                Console.WriteLine("1. View All Posts");
                Console.WriteLine("2. View One Post");
                Console.WriteLine("3. Add New Post");
                Console.WriteLine("4. Update Post");
                Console.WriteLine("5. Delete Post");
                Console.WriteLine("6. Quit");
                Console.Write("Enter your choice: ");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice) {
                    case 1: await ShowAllPosts(); break;
                    case 2: await ShowPost(); break;
                    case 3: await InsertPost(); break;
                    case 4: await UpdatePost(); break;
                    case 5: await DeletePost(); break;
                    case 6: return;
                }
            }
        }
        private static async Task DeletePost() {
            Console.Write("Enter the post id to view: ");
            int id = Convert.ToInt32(Console.ReadLine());
            Post post = await svc.GetFromJsonAsync<Post>("" + id);
            Console.WriteLine($"Post Id: {post.Id}, User Id: {post.UserId}, Title: {post.Title}, Body: {post.Body}");
            Console.WriteLine("Are you sure to delete? ");
            char ch = Convert.ToChar(Console.ReadLine());
            if (ch == 'y') {
                await svc.DeleteAsync("" + id);
                Console.WriteLine("Post deleted.");
            }
        }
        private static async Task UpdatePost() {
            Console.Write("Enter the post id to update: ");
            int id = Convert.ToInt32(Console.ReadLine());
            Post post = await svc.GetFromJsonAsync<Post>("" + id);
            Console.WriteLine($"Post Id: {post.Id}, User Id: {post.UserId}, Title: {post.Title}, Body: {post.Body}");
            Console.Write("Enter the new user id: ");
            post.UserId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the new title: ");
            post.Title = Console.ReadLine();
            Console.Write("Enter the new body: ");
            post.Body = Console.ReadLine();
            await svc.PutAsJsonAsync<Post>("" + id, post);
            Console.WriteLine("Post details updated.");
        }
        private static async Task InsertPost() {
            Post post = new Post();
            Console.Write("Enter the post id: ");
            post.Id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the user id: ");
            post.UserId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the title: ");
            post.Title = Console.ReadLine();
            Console.Write("Enter the body: ");
            post.Body = Console.ReadLine();
            await svc.PostAsJsonAsync<Post>("", post);
            Console.WriteLine("New post added.");
        }
        private static async Task ShowPost() {
            Console.Write("Enter the post id to view: ");
            int id = Convert.ToInt32(Console.ReadLine());
            Post post = await svc.GetFromJsonAsync<Post>("" + id);
            Console.WriteLine($"Post Id: {post.Id}, User Id: {post.UserId}, Title: {post.Title}, Body: {post.Body}");
        }
        private static async Task ShowAllPosts() {
            List<Post> posts = await svc.GetFromJsonAsync<List<Post>>("");
            Console.WriteLine("List of posts...");
            foreach (Post post in posts) {
                Console.WriteLine($"Post Id: {post.Id}, User Id: {post.UserId}, Title: {post.Title}, Body: {post.Body}");
            }
        }
    }
}
