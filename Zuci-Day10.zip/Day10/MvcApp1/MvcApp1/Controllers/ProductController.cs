﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MvcApp1.Models;

namespace MvcApp1.Controllers
{
    public class ProductController : Controller {
        ProductRepository repo = new ProductRepository();
        public ActionResult Index() {
            List<Product> products = repo.GetAllProducts();
            return View(products);
        }
        public ActionResult Details(int id) {
            Product product = repo.GetProductById(id);
            return View(product);
        }
        public ActionResult Create() {
            Product product = new Product();
            return View(product);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product product) {
            try {
                repo.NewProduct(product);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public ActionResult Edit(int id) {
            Product product = repo.GetProductById(id);
            return View(product);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Product product) {
            try {
                repo.UpdateProduct(id, product);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public ActionResult Delete(int id) {
            Product product = repo.GetProductById(id);
            return View(product);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection) {
            try {
                repo.DeleteProduct(id);
                return RedirectToAction(nameof(Index));
            }
            catch {
                return View();
            }
        }
        public ActionResult GetByCategory(string cat) {
            List<Product> prods = repo.GetProductsByCategory(cat);
            return View(prods);
        }
    }
}
