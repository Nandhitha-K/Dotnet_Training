﻿using System.Collections;

namespace MvcApp1.Models
{
    public interface IProductRepo
    {
        void NewProduct(Product prod);
        List<Product> GetAllProducts();
        List<Product> GetProductsByCategory(string cat);
        Product GetProductById(int id);
        void UpdateProduct(int id, Product prod);
        void DeleteProduct(int id);
    }
}
