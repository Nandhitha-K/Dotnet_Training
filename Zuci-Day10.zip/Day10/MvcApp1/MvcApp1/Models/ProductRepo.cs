﻿using System.Collections;

namespace MvcApp1.Models
{
    public class ProductRepository : IProductRepo
    {
        static List<Product> products = new List<Product>();
        public void DeleteProduct(int id)
        {
            Product prod = GetProductById(id);
            products.Remove(prod);
        }
        public List<Product> GetAllProducts()
        {
            return products;
        }
        public Product GetProductById(int id)
        {
            Product prod = null;
            foreach (Product i in products)
            {
                if (i.ProductId == id)
                {
                    prod = i;
                    break;
                }
            }
            return prod;
        }
        public List<Product> GetProductsByCategory(string cat)
        {
            List<Product> catProd = new List<Product>();
            foreach (Product i in products)
            {
                if (i.Category == cat)
                {
                    catProd.Add(i);
                }
            }
            return catProd;
        }
        public void NewProduct(Product prod)
        {
            products.Add(prod);
        }
        public void UpdateProduct(int id, Product prod)
        {
            Product p1 = GetProductById(id);
            p1.ProductName = prod.ProductName;
            p1.Price = prod.Price;
            p1.Category = prod.Category;
        }
    }
}
